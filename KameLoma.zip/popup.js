(function() {
  "use strict";
  var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
  var ViterbiNode_1;
  var hasRequiredViterbiNode;
  function requireViterbiNode() {
    if (hasRequiredViterbiNode) return ViterbiNode_1;
    hasRequiredViterbiNode = 1;
    function ViterbiNode(node_name, node_cost, start_pos, length, type, left_id, right_id, surface_form) {
      this.name = node_name;
      this.cost = node_cost;
      this.start_pos = start_pos;
      this.length = length;
      this.left_id = left_id;
      this.right_id = right_id;
      this.prev = null;
      this.surface_form = surface_form;
      if (type === "BOS") {
        this.shortest_cost = 0;
      } else {
        this.shortest_cost = Number.MAX_VALUE;
      }
      this.type = type;
    }
    ViterbiNode_1 = ViterbiNode;
    return ViterbiNode_1;
  }
  var ViterbiLattice_1;
  var hasRequiredViterbiLattice;
  function requireViterbiLattice() {
    if (hasRequiredViterbiLattice) return ViterbiLattice_1;
    hasRequiredViterbiLattice = 1;
    var ViterbiNode = requireViterbiNode();
    function ViterbiLattice() {
      this.nodes_end_at = [];
      this.nodes_end_at[0] = [new ViterbiNode(-1, 0, 0, 0, "BOS", 0, 0, "")];
      this.eos_pos = 1;
    }
    ViterbiLattice.prototype.append = function(node) {
      var last_pos = node.start_pos + node.length - 1;
      if (this.eos_pos < last_pos) {
        this.eos_pos = last_pos;
      }
      var prev_nodes = this.nodes_end_at[last_pos];
      if (prev_nodes == null) {
        prev_nodes = [];
      }
      prev_nodes.push(node);
      this.nodes_end_at[last_pos] = prev_nodes;
    };
    ViterbiLattice.prototype.appendEos = function() {
      var last_index = this.nodes_end_at.length;
      this.eos_pos++;
      this.nodes_end_at[last_index] = [new ViterbiNode(-1, 0, this.eos_pos, 0, "EOS", 0, 0, "")];
    };
    ViterbiLattice_1 = ViterbiLattice;
    return ViterbiLattice_1;
  }
  var SurrogateAwareString_1;
  var hasRequiredSurrogateAwareString;
  function requireSurrogateAwareString() {
    if (hasRequiredSurrogateAwareString) return SurrogateAwareString_1;
    hasRequiredSurrogateAwareString = 1;
    function SurrogateAwareString(str) {
      this.str = str;
      this.index_mapping = [];
      for (var pos = 0; pos < str.length; pos++) {
        var ch = str.charAt(pos);
        this.index_mapping.push(pos);
        if (SurrogateAwareString.isSurrogatePair(ch)) {
          pos++;
        }
      }
      this.length = this.index_mapping.length;
    }
    SurrogateAwareString.prototype.slice = function(index) {
      if (this.index_mapping.length <= index) {
        return "";
      }
      var surrogate_aware_index = this.index_mapping[index];
      return this.str.slice(surrogate_aware_index);
    };
    SurrogateAwareString.prototype.charAt = function(index) {
      if (this.str.length <= index) {
        return "";
      }
      var surrogate_aware_start_index = this.index_mapping[index];
      var surrogate_aware_end_index = this.index_mapping[index + 1];
      if (surrogate_aware_end_index == null) {
        return this.str.slice(surrogate_aware_start_index);
      }
      return this.str.slice(surrogate_aware_start_index, surrogate_aware_end_index);
    };
    SurrogateAwareString.prototype.charCodeAt = function(index) {
      if (this.index_mapping.length <= index) {
        return NaN;
      }
      var surrogate_aware_index = this.index_mapping[index];
      var upper = this.str.charCodeAt(surrogate_aware_index);
      var lower;
      if (upper >= 55296 && upper <= 56319 && surrogate_aware_index < this.str.length) {
        lower = this.str.charCodeAt(surrogate_aware_index + 1);
        if (lower >= 56320 && lower <= 57343) {
          return (upper - 55296) * 1024 + lower - 56320 + 65536;
        }
      }
      return upper;
    };
    SurrogateAwareString.prototype.toString = function() {
      return this.str;
    };
    SurrogateAwareString.isSurrogatePair = function(ch) {
      var utf16_code = ch.charCodeAt(0);
      if (utf16_code >= 55296 && utf16_code <= 56319) {
        return true;
      } else {
        return false;
      }
    };
    SurrogateAwareString_1 = SurrogateAwareString;
    return SurrogateAwareString_1;
  }
  var ViterbiBuilder_1;
  var hasRequiredViterbiBuilder;
  function requireViterbiBuilder() {
    if (hasRequiredViterbiBuilder) return ViterbiBuilder_1;
    hasRequiredViterbiBuilder = 1;
    var ViterbiNode = requireViterbiNode();
    var ViterbiLattice = requireViterbiLattice();
    var SurrogateAwareString = requireSurrogateAwareString();
    function ViterbiBuilder(dic) {
      this.trie = dic.trie;
      this.token_info_dictionary = dic.token_info_dictionary;
      this.unknown_dictionary = dic.unknown_dictionary;
    }
    ViterbiBuilder.prototype.build = function(sentence_str) {
      var lattice = new ViterbiLattice();
      var sentence = new SurrogateAwareString(sentence_str);
      var key, trie_id, left_id, right_id, word_cost;
      for (var pos = 0; pos < sentence.length; pos++) {
        var tail = sentence.slice(pos);
        var vocabulary = this.trie.commonPrefixSearch(tail);
        for (var n = 0; n < vocabulary.length; n++) {
          trie_id = vocabulary[n].v;
          key = vocabulary[n].k;
          var token_info_ids = this.token_info_dictionary.target_map[trie_id];
          for (var i = 0; i < token_info_ids.length; i++) {
            var token_info_id = parseInt(token_info_ids[i]);
            left_id = this.token_info_dictionary.dictionary.getShort(token_info_id);
            right_id = this.token_info_dictionary.dictionary.getShort(token_info_id + 2);
            word_cost = this.token_info_dictionary.dictionary.getShort(token_info_id + 4);
            lattice.append(new ViterbiNode(token_info_id, word_cost, pos + 1, key.length, "KNOWN", left_id, right_id, key));
          }
        }
        var surrogate_aware_tail = new SurrogateAwareString(tail);
        var head_char = new SurrogateAwareString(surrogate_aware_tail.charAt(0));
        var head_char_class = this.unknown_dictionary.lookup(head_char.toString());
        if (vocabulary == null || vocabulary.length === 0 || head_char_class.is_always_invoke === 1) {
          key = head_char;
          if (head_char_class.is_grouping === 1 && 1 < surrogate_aware_tail.length) {
            for (var k = 1; k < surrogate_aware_tail.length; k++) {
              var next_char = surrogate_aware_tail.charAt(k);
              var next_char_class = this.unknown_dictionary.lookup(next_char);
              if (head_char_class.class_name !== next_char_class.class_name) {
                break;
              }
              key += next_char;
            }
          }
          var unk_ids = this.unknown_dictionary.target_map[head_char_class.class_id];
          for (var j = 0; j < unk_ids.length; j++) {
            var unk_id = parseInt(unk_ids[j]);
            left_id = this.unknown_dictionary.dictionary.getShort(unk_id);
            right_id = this.unknown_dictionary.dictionary.getShort(unk_id + 2);
            word_cost = this.unknown_dictionary.dictionary.getShort(unk_id + 4);
            lattice.append(new ViterbiNode(unk_id, word_cost, pos + 1, key.length, "UNKNOWN", left_id, right_id, key.toString()));
          }
        }
      }
      lattice.appendEos();
      return lattice;
    };
    ViterbiBuilder_1 = ViterbiBuilder;
    return ViterbiBuilder_1;
  }
  var ViterbiSearcher_1;
  var hasRequiredViterbiSearcher;
  function requireViterbiSearcher() {
    if (hasRequiredViterbiSearcher) return ViterbiSearcher_1;
    hasRequiredViterbiSearcher = 1;
    function ViterbiSearcher(connection_costs) {
      this.connection_costs = connection_costs;
    }
    ViterbiSearcher.prototype.search = function(lattice) {
      lattice = this.forward(lattice);
      return this.backward(lattice);
    };
    ViterbiSearcher.prototype.forward = function(lattice) {
      var i, j, k;
      for (i = 1; i <= lattice.eos_pos; i++) {
        var nodes = lattice.nodes_end_at[i];
        if (nodes == null) {
          continue;
        }
        for (j = 0; j < nodes.length; j++) {
          var node = nodes[j];
          var cost = Number.MAX_VALUE;
          var shortest_prev_node;
          var prev_nodes = lattice.nodes_end_at[node.start_pos - 1];
          if (prev_nodes == null) {
            continue;
          }
          for (k = 0; k < prev_nodes.length; k++) {
            var prev_node = prev_nodes[k];
            var edge_cost;
            if (node.left_id == null || prev_node.right_id == null) {
              console.log("Left or right is null");
              edge_cost = 0;
            } else {
              edge_cost = this.connection_costs.get(prev_node.right_id, node.left_id);
            }
            var _cost = prev_node.shortest_cost + edge_cost + node.cost;
            if (_cost < cost) {
              shortest_prev_node = prev_node;
              cost = _cost;
            }
          }
          node.prev = shortest_prev_node;
          node.shortest_cost = cost;
        }
      }
      return lattice;
    };
    ViterbiSearcher.prototype.backward = function(lattice) {
      var shortest_path = [];
      var eos = lattice.nodes_end_at[lattice.nodes_end_at.length - 1][0];
      var node_back = eos.prev;
      if (node_back == null) {
        return [];
      }
      while (node_back.type !== "BOS") {
        shortest_path.push(node_back);
        if (node_back.prev == null) {
          return [];
        }
        node_back = node_back.prev;
      }
      return shortest_path.reverse();
    };
    ViterbiSearcher_1 = ViterbiSearcher;
    return ViterbiSearcher_1;
  }
  var IpadicFormatter_1;
  var hasRequiredIpadicFormatter;
  function requireIpadicFormatter() {
    if (hasRequiredIpadicFormatter) return IpadicFormatter_1;
    hasRequiredIpadicFormatter = 1;
    function IpadicFormatter() {
    }
    IpadicFormatter.prototype.formatEntry = function(word_id, position, type, features) {
      var token = {};
      token.word_id = word_id;
      token.word_type = type;
      token.word_position = position;
      token.surface_form = features[0];
      token.pos = features[1];
      token.pos_detail_1 = features[2];
      token.pos_detail_2 = features[3];
      token.pos_detail_3 = features[4];
      token.conjugated_type = features[5];
      token.conjugated_form = features[6];
      token.basic_form = features[7];
      token.reading = features[8];
      token.pronunciation = features[9];
      return token;
    };
    IpadicFormatter.prototype.formatUnknownEntry = function(word_id, position, type, features, surface_form) {
      var token = {};
      token.word_id = word_id;
      token.word_type = type;
      token.word_position = position;
      token.surface_form = surface_form;
      token.pos = features[1];
      token.pos_detail_1 = features[2];
      token.pos_detail_2 = features[3];
      token.pos_detail_3 = features[4];
      token.conjugated_type = features[5];
      token.conjugated_form = features[6];
      token.basic_form = features[7];
      return token;
    };
    IpadicFormatter_1 = IpadicFormatter;
    return IpadicFormatter_1;
  }
  var Tokenizer_1;
  var hasRequiredTokenizer;
  function requireTokenizer() {
    if (hasRequiredTokenizer) return Tokenizer_1;
    hasRequiredTokenizer = 1;
    var ViterbiBuilder = requireViterbiBuilder();
    var ViterbiSearcher = requireViterbiSearcher();
    var IpadicFormatter = requireIpadicFormatter();
    var PUNCTUATION = /、|。/;
    function Tokenizer(dic) {
      this.token_info_dictionary = dic.token_info_dictionary;
      this.unknown_dictionary = dic.unknown_dictionary;
      this.viterbi_builder = new ViterbiBuilder(dic);
      this.viterbi_searcher = new ViterbiSearcher(dic.connection_costs);
      this.formatter = new IpadicFormatter();
    }
    Tokenizer.splitByPunctuation = function(input) {
      var sentences = [];
      var tail = input;
      while (true) {
        if (tail === "") {
          break;
        }
        var index = tail.search(PUNCTUATION);
        if (index < 0) {
          sentences.push(tail);
          break;
        }
        sentences.push(tail.substring(0, index + 1));
        tail = tail.substring(index + 1);
      }
      return sentences;
    };
    Tokenizer.prototype.tokenize = function(text) {
      var sentences = Tokenizer.splitByPunctuation(text);
      var tokens = [];
      for (var i = 0; i < sentences.length; i++) {
        var sentence = sentences[i];
        this.tokenizeForSentence(sentence, tokens);
      }
      return tokens;
    };
    Tokenizer.prototype.tokenizeForSentence = function(sentence, tokens) {
      if (tokens == null) {
        tokens = [];
      }
      var lattice = this.getLattice(sentence);
      var best_path = this.viterbi_searcher.search(lattice);
      var last_pos = 0;
      if (tokens.length > 0) {
        last_pos = tokens[tokens.length - 1].word_position;
      }
      for (var j = 0; j < best_path.length; j++) {
        var node = best_path[j];
        var token, features, features_line;
        if (node.type === "KNOWN") {
          features_line = this.token_info_dictionary.getFeatures(node.name);
          if (features_line == null) {
            features = [];
          } else {
            features = features_line.split(",");
          }
          token = this.formatter.formatEntry(node.name, last_pos + node.start_pos, node.type, features);
        } else if (node.type === "UNKNOWN") {
          features_line = this.unknown_dictionary.getFeatures(node.name);
          if (features_line == null) {
            features = [];
          } else {
            features = features_line.split(",");
          }
          token = this.formatter.formatUnknownEntry(node.name, last_pos + node.start_pos, node.type, features, node.surface_form);
        } else {
          token = this.formatter.formatEntry(node.name, last_pos + node.start_pos, node.type, []);
        }
        tokens.push(token);
      }
      return tokens;
    };
    Tokenizer.prototype.getLattice = function(text) {
      return this.viterbi_builder.build(text);
    };
    Tokenizer_1 = Tokenizer;
    return Tokenizer_1;
  }
  var gunzip_min = {};
  var hasRequiredGunzip_min;
  function requireGunzip_min() {
    if (hasRequiredGunzip_min) return gunzip_min;
    hasRequiredGunzip_min = 1;
    (function() {
      function n(e) {
        throw e;
      }
      var p = void 0, aa = this;
      function t(e, b) {
        var d = e.split("."), c = aa;
        !(d[0] in c) && c.execScript && c.execScript("var " + d[0]);
        for (var a; d.length && (a = d.shift()); ) !d.length && b !== p ? c[a] = b : c = c[a] ? c[a] : c[a] = {};
      }
      var x = "undefined" !== typeof Uint8Array && "undefined" !== typeof Uint16Array && "undefined" !== typeof Uint32Array && "undefined" !== typeof DataView;
      new (x ? Uint8Array : Array)(256);
      function B(e, b, d) {
        var c, a = "number" === typeof b ? b : b = 0, f = "number" === typeof d ? d : e.length;
        c = -1;
        for (a = f & 7; a--; ++b) c = c >>> 8 ^ C[(c ^ e[b]) & 255];
        for (a = f >> 3; a--; b += 8) c = c >>> 8 ^ C[(c ^ e[b]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 1]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 2]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 3]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 4]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 5]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 6]) & 255], c = c >>> 8 ^ C[(c ^ e[b + 7]) & 255];
        return (c ^ 4294967295) >>> 0;
      }
      var D = [
        0,
        1996959894,
        3993919788,
        2567524794,
        124634137,
        1886057615,
        3915621685,
        2657392035,
        249268274,
        2044508324,
        3772115230,
        2547177864,
        162941995,
        2125561021,
        3887607047,
        2428444049,
        498536548,
        1789927666,
        4089016648,
        2227061214,
        450548861,
        1843258603,
        4107580753,
        2211677639,
        325883990,
        1684777152,
        4251122042,
        2321926636,
        335633487,
        1661365465,
        4195302755,
        2366115317,
        997073096,
        1281953886,
        3579855332,
        2724688242,
        1006888145,
        1258607687,
        3524101629,
        2768942443,
        901097722,
        1119000684,
        3686517206,
        2898065728,
        853044451,
        1172266101,
        3705015759,
        2882616665,
        651767980,
        1373503546,
        3369554304,
        3218104598,
        565507253,
        1454621731,
        3485111705,
        3099436303,
        671266974,
        1594198024,
        3322730930,
        2970347812,
        795835527,
        1483230225,
        3244367275,
        3060149565,
        1994146192,
        31158534,
        2563907772,
        4023717930,
        1907459465,
        112637215,
        2680153253,
        3904427059,
        2013776290,
        251722036,
        2517215374,
        3775830040,
        2137656763,
        141376813,
        2439277719,
        3865271297,
        1802195444,
        476864866,
        2238001368,
        4066508878,
        1812370925,
        453092731,
        2181625025,
        4111451223,
        1706088902,
        314042704,
        2344532202,
        4240017532,
        1658658271,
        366619977,
        2362670323,
        4224994405,
        1303535960,
        984961486,
        2747007092,
        3569037538,
        1256170817,
        1037604311,
        2765210733,
        3554079995,
        1131014506,
        879679996,
        2909243462,
        3663771856,
        1141124467,
        855842277,
        2852801631,
        3708648649,
        1342533948,
        654459306,
        3188396048,
        3373015174,
        1466479909,
        544179635,
        3110523913,
        3462522015,
        1591671054,
        702138776,
        2966460450,
        3352799412,
        1504918807,
        783551873,
        3082640443,
        3233442989,
        3988292384,
        2596254646,
        62317068,
        1957810842,
        3939845945,
        2647816111,
        81470997,
        1943803523,
        3814918930,
        2489596804,
        225274430,
        2053790376,
        3826175755,
        2466906013,
        167816743,
        2097651377,
        4027552580,
        2265490386,
        503444072,
        1762050814,
        4150417245,
        2154129355,
        426522225,
        1852507879,
        4275313526,
        2312317920,
        282753626,
        1742555852,
        4189708143,
        2394877945,
        397917763,
        1622183637,
        3604390888,
        2714866558,
        953729732,
        1340076626,
        3518719985,
        2797360999,
        1068828381,
        1219638859,
        3624741850,
        2936675148,
        906185462,
        1090812512,
        3747672003,
        2825379669,
        829329135,
        1181335161,
        3412177804,
        3160834842,
        628085408,
        1382605366,
        3423369109,
        3138078467,
        570562233,
        1426400815,
        3317316542,
        2998733608,
        733239954,
        1555261956,
        3268935591,
        3050360625,
        752459403,
        1541320221,
        2607071920,
        3965973030,
        1969922972,
        40735498,
        2617837225,
        3943577151,
        1913087877,
        83908371,
        2512341634,
        3803740692,
        2075208622,
        213261112,
        2463272603,
        3855990285,
        2094854071,
        198958881,
        2262029012,
        4057260610,
        1759359992,
        534414190,
        2176718541,
        4139329115,
        1873836001,
        414664567,
        2282248934,
        4279200368,
        1711684554,
        285281116,
        2405801727,
        4167216745,
        1634467795,
        376229701,
        2685067896,
        3608007406,
        1308918612,
        956543938,
        2808555105,
        3495958263,
        1231636301,
        1047427035,
        2932959818,
        3654703836,
        1088359270,
        936918e3,
        2847714899,
        3736837829,
        1202900863,
        817233897,
        3183342108,
        3401237130,
        1404277552,
        615818150,
        3134207493,
        3453421203,
        1423857449,
        601450431,
        3009837614,
        3294710456,
        1567103746,
        711928724,
        3020668471,
        3272380065,
        1510334235,
        755167117
      ], C = x ? new Uint32Array(D) : D;
      function E() {
      }
      E.prototype.getName = function() {
        return this.name;
      };
      E.prototype.getData = function() {
        return this.data;
      };
      E.prototype.G = function() {
        return this.H;
      };
      function G(e) {
        var b = e.length, d = 0, c = Number.POSITIVE_INFINITY, a, f, k, l, m, r, q, g, h, v;
        for (g = 0; g < b; ++g) e[g] > d && (d = e[g]), e[g] < c && (c = e[g]);
        a = 1 << d;
        f = new (x ? Uint32Array : Array)(a);
        k = 1;
        l = 0;
        for (m = 2; k <= d; ) {
          for (g = 0; g < b; ++g) if (e[g] === k) {
            r = 0;
            q = l;
            for (h = 0; h < k; ++h) r = r << 1 | q & 1, q >>= 1;
            v = k << 16 | g;
            for (h = r; h < a; h += m) f[h] = v;
            ++l;
          }
          ++k;
          l <<= 1;
          m <<= 1;
        }
        return [f, d, c];
      }
      var K;
      for (K = 0; 288 > K; K++) switch (true) {
        case 143 >= K:
          break;
        case 255 >= K:
          break;
        case 279 >= K:
          break;
        case 287 >= K:
          break;
        default:
          n("invalid literal: " + K);
      }
      (function() {
        function e(a) {
          switch (true) {
            case 3 === a:
              return [257, a - 3, 0];
            case 4 === a:
              return [258, a - 4, 0];
            case 5 === a:
              return [259, a - 5, 0];
            case 6 === a:
              return [260, a - 6, 0];
            case 7 === a:
              return [261, a - 7, 0];
            case 8 === a:
              return [262, a - 8, 0];
            case 9 === a:
              return [263, a - 9, 0];
            case 10 === a:
              return [264, a - 10, 0];
            case 12 >= a:
              return [265, a - 11, 1];
            case 14 >= a:
              return [266, a - 13, 1];
            case 16 >= a:
              return [267, a - 15, 1];
            case 18 >= a:
              return [268, a - 17, 1];
            case 22 >= a:
              return [269, a - 19, 2];
            case 26 >= a:
              return [270, a - 23, 2];
            case 30 >= a:
              return [271, a - 27, 2];
            case 34 >= a:
              return [
                272,
                a - 31,
                2
              ];
            case 42 >= a:
              return [273, a - 35, 3];
            case 50 >= a:
              return [274, a - 43, 3];
            case 58 >= a:
              return [275, a - 51, 3];
            case 66 >= a:
              return [276, a - 59, 3];
            case 82 >= a:
              return [277, a - 67, 4];
            case 98 >= a:
              return [278, a - 83, 4];
            case 114 >= a:
              return [279, a - 99, 4];
            case 130 >= a:
              return [280, a - 115, 4];
            case 162 >= a:
              return [281, a - 131, 5];
            case 194 >= a:
              return [282, a - 163, 5];
            case 226 >= a:
              return [283, a - 195, 5];
            case 257 >= a:
              return [284, a - 227, 5];
            case 258 === a:
              return [285, a - 258, 0];
            default:
              n("invalid length: " + a);
          }
        }
        var b = [], d, c;
        for (d = 3; 258 >= d; d++) c = e(d), b[d] = c[2] << 24 | c[1] << 16 | c[0];
        return b;
      })();
      function L(e, b) {
        this.i = [];
        this.j = 32768;
        this.d = this.f = this.c = this.n = 0;
        this.input = x ? new Uint8Array(e) : e;
        this.o = false;
        this.k = M;
        this.w = false;
        if (b || !(b = {})) b.index && (this.c = b.index), b.bufferSize && (this.j = b.bufferSize), b.bufferType && (this.k = b.bufferType), b.resize && (this.w = b.resize);
        switch (this.k) {
          case N:
            this.a = 32768;
            this.b = new (x ? Uint8Array : Array)(32768 + this.j + 258);
            break;
          case M:
            this.a = 0;
            this.b = new (x ? Uint8Array : Array)(this.j);
            this.e = this.D;
            this.q = this.A;
            this.l = this.C;
            break;
          default:
            n(Error("invalid inflate mode"));
        }
      }
      var N = 0, M = 1;
      L.prototype.g = function() {
        for (; !this.o; ) {
          var e = P(this, 3);
          e & 1 && (this.o = true);
          e >>>= 1;
          switch (e) {
            case 0:
              var b = this.input, d = this.c, c = this.b, a = this.a, f = b.length, k = p, l = p, m = c.length, r = p;
              this.d = this.f = 0;
              d + 1 >= f && n(Error("invalid uncompressed block header: LEN"));
              k = b[d++] | b[d++] << 8;
              d + 1 >= f && n(Error("invalid uncompressed block header: NLEN"));
              l = b[d++] | b[d++] << 8;
              k === ~l && n(Error("invalid uncompressed block header: length verify"));
              d + k > b.length && n(Error("input buffer is broken"));
              switch (this.k) {
                case N:
                  for (; a + k > c.length; ) {
                    r = m - a;
                    k -= r;
                    if (x) c.set(b.subarray(d, d + r), a), a += r, d += r;
                    else for (; r--; ) c[a++] = b[d++];
                    this.a = a;
                    c = this.e();
                    a = this.a;
                  }
                  break;
                case M:
                  for (; a + k > c.length; ) c = this.e({ t: 2 });
                  break;
                default:
                  n(Error("invalid inflate mode"));
              }
              if (x) c.set(b.subarray(d, d + k), a), a += k, d += k;
              else for (; k--; ) c[a++] = b[d++];
              this.c = d;
              this.a = a;
              this.b = c;
              break;
            case 1:
              this.l(da, ea);
              break;
            case 2:
              for (var q = P(this, 5) + 257, g = P(this, 5) + 1, h = P(this, 4) + 4, v = new (x ? Uint8Array : Array)(Q.length), s = p, F = p, H = p, w = p, z = p, O = p, I = p, u = p, Z = p, u = 0; u < h; ++u) v[Q[u]] = P(this, 3);
              if (!x) {
                u = h;
                for (h = v.length; u < h; ++u) v[Q[u]] = 0;
              }
              s = G(v);
              w = new (x ? Uint8Array : Array)(q + g);
              u = 0;
              for (Z = q + g; u < Z; ) switch (z = R(this, s), z) {
                case 16:
                  for (I = 3 + P(this, 2); I--; ) w[u++] = O;
                  break;
                case 17:
                  for (I = 3 + P(this, 3); I--; ) w[u++] = 0;
                  O = 0;
                  break;
                case 18:
                  for (I = 11 + P(this, 7); I--; ) w[u++] = 0;
                  O = 0;
                  break;
                default:
                  O = w[u++] = z;
              }
              F = x ? G(w.subarray(0, q)) : G(w.slice(0, q));
              H = x ? G(w.subarray(q)) : G(w.slice(q));
              this.l(F, H);
              break;
            default:
              n(Error("unknown BTYPE: " + e));
          }
        }
        return this.q();
      };
      var S = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], Q = x ? new Uint16Array(S) : S, fa = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 258, 258], ga = x ? new Uint16Array(fa) : fa, ha = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0], T = x ? new Uint8Array(ha) : ha, ia = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577], ja = x ? new Uint16Array(ia) : ia, ka = [
        0,
        0,
        0,
        0,
        1,
        1,
        2,
        2,
        3,
        3,
        4,
        4,
        5,
        5,
        6,
        6,
        7,
        7,
        8,
        8,
        9,
        9,
        10,
        10,
        11,
        11,
        12,
        12,
        13,
        13
      ], U = x ? new Uint8Array(ka) : ka, V = new (x ? Uint8Array : Array)(288), W, la;
      W = 0;
      for (la = V.length; W < la; ++W) V[W] = 143 >= W ? 8 : 255 >= W ? 9 : 279 >= W ? 7 : 8;
      var da = G(V), X = new (x ? Uint8Array : Array)(30), Y, ma;
      Y = 0;
      for (ma = X.length; Y < ma; ++Y) X[Y] = 5;
      var ea = G(X);
      function P(e, b) {
        for (var d = e.f, c = e.d, a = e.input, f = e.c, k = a.length, l; c < b; ) f >= k && n(Error("input buffer is broken")), d |= a[f++] << c, c += 8;
        l = d & (1 << b) - 1;
        e.f = d >>> b;
        e.d = c - b;
        e.c = f;
        return l;
      }
      function R(e, b) {
        for (var d = e.f, c = e.d, a = e.input, f = e.c, k = a.length, l = b[0], m = b[1], r, q; c < m && !(f >= k); ) d |= a[f++] << c, c += 8;
        r = l[d & (1 << m) - 1];
        q = r >>> 16;
        q > c && n(Error("invalid code length: " + q));
        e.f = d >> q;
        e.d = c - q;
        e.c = f;
        return r & 65535;
      }
      L.prototype.l = function(e, b) {
        var d = this.b, c = this.a;
        this.r = e;
        for (var a = d.length - 258, f, k, l, m; 256 !== (f = R(this, e)); ) if (256 > f) c >= a && (this.a = c, d = this.e(), c = this.a), d[c++] = f;
        else {
          k = f - 257;
          m = ga[k];
          0 < T[k] && (m += P(this, T[k]));
          f = R(this, b);
          l = ja[f];
          0 < U[f] && (l += P(this, U[f]));
          c >= a && (this.a = c, d = this.e(), c = this.a);
          for (; m--; ) d[c] = d[c++ - l];
        }
        for (; 8 <= this.d; ) this.d -= 8, this.c--;
        this.a = c;
      };
      L.prototype.C = function(e, b) {
        var d = this.b, c = this.a;
        this.r = e;
        for (var a = d.length, f, k, l, m; 256 !== (f = R(this, e)); ) if (256 > f) c >= a && (d = this.e(), a = d.length), d[c++] = f;
        else {
          k = f - 257;
          m = ga[k];
          0 < T[k] && (m += P(this, T[k]));
          f = R(this, b);
          l = ja[f];
          0 < U[f] && (l += P(this, U[f]));
          c + m > a && (d = this.e(), a = d.length);
          for (; m--; ) d[c] = d[c++ - l];
        }
        for (; 8 <= this.d; ) this.d -= 8, this.c--;
        this.a = c;
      };
      L.prototype.e = function() {
        var e = new (x ? Uint8Array : Array)(this.a - 32768), b = this.a - 32768, d, c, a = this.b;
        if (x) e.set(a.subarray(32768, e.length));
        else {
          d = 0;
          for (c = e.length; d < c; ++d) e[d] = a[d + 32768];
        }
        this.i.push(e);
        this.n += e.length;
        if (x) a.set(a.subarray(b, b + 32768));
        else for (d = 0; 32768 > d; ++d) a[d] = a[b + d];
        this.a = 32768;
        return a;
      };
      L.prototype.D = function(e) {
        var b, d = this.input.length / this.c + 1 | 0, c, a, f, k = this.input, l = this.b;
        e && ("number" === typeof e.t && (d = e.t), "number" === typeof e.z && (d += e.z));
        2 > d ? (c = (k.length - this.c) / this.r[2], f = 258 * (c / 2) | 0, a = f < l.length ? l.length + f : l.length << 1) : a = l.length * d;
        x ? (b = new Uint8Array(a), b.set(l)) : b = l;
        return this.b = b;
      };
      L.prototype.q = function() {
        var e = 0, b = this.b, d = this.i, c, a = new (x ? Uint8Array : Array)(this.n + (this.a - 32768)), f, k, l, m;
        if (0 === d.length) return x ? this.b.subarray(32768, this.a) : this.b.slice(32768, this.a);
        f = 0;
        for (k = d.length; f < k; ++f) {
          c = d[f];
          l = 0;
          for (m = c.length; l < m; ++l) a[e++] = c[l];
        }
        f = 32768;
        for (k = this.a; f < k; ++f) a[e++] = b[f];
        this.i = [];
        return this.buffer = a;
      };
      L.prototype.A = function() {
        var e, b = this.a;
        x ? this.w ? (e = new Uint8Array(b), e.set(this.b.subarray(0, b))) : e = this.b.subarray(0, b) : (this.b.length > b && (this.b.length = b), e = this.b);
        return this.buffer = e;
      };
      function $(e) {
        this.input = e;
        this.c = 0;
        this.m = [];
        this.s = false;
      }
      $.prototype.F = function() {
        this.s || this.g();
        return this.m.slice();
      };
      $.prototype.g = function() {
        for (var e = this.input.length; this.c < e; ) {
          var b = new E(), d = p, c = p, a = p, f = p, k = p, l = p, m = p, r = p, q = p, g = this.input, h = this.c;
          b.u = g[h++];
          b.v = g[h++];
          (31 !== b.u || 139 !== b.v) && n(Error("invalid file signature:" + b.u + "," + b.v));
          b.p = g[h++];
          switch (b.p) {
            case 8:
              break;
            default:
              n(Error("unknown compression method: " + b.p));
          }
          b.h = g[h++];
          r = g[h++] | g[h++] << 8 | g[h++] << 16 | g[h++] << 24;
          b.H = new Date(1e3 * r);
          b.N = g[h++];
          b.M = g[h++];
          0 < (b.h & 4) && (b.I = g[h++] | g[h++] << 8, h += b.I);
          if (0 < (b.h & 8)) {
            m = [];
            for (l = 0; 0 < (k = g[h++]); ) m[l++] = String.fromCharCode(k);
            b.name = m.join("");
          }
          if (0 < (b.h & 16)) {
            m = [];
            for (l = 0; 0 < (k = g[h++]); ) m[l++] = String.fromCharCode(k);
            b.J = m.join("");
          }
          0 < (b.h & 2) && (b.B = B(g, 0, h) & 65535, b.B !== (g[h++] | g[h++] << 8) && n(Error("invalid header crc16")));
          d = g[g.length - 4] | g[g.length - 3] << 8 | g[g.length - 2] << 16 | g[g.length - 1] << 24;
          g.length - h - 4 - 4 < 512 * d && (f = d);
          c = new L(g, { index: h, bufferSize: f });
          b.data = a = c.g();
          h = c.c;
          b.K = q = (g[h++] | g[h++] << 8 | g[h++] << 16 | g[h++] << 24) >>> 0;
          B(a, p, p) !== q && n(Error("invalid CRC-32 checksum: 0x" + B(a, p, p).toString(16) + " / 0x" + q.toString(16)));
          b.L = d = (g[h++] | g[h++] << 8 | g[h++] << 16 | g[h++] << 24) >>> 0;
          (a.length & 4294967295) !== d && n(Error("invalid input size: " + (a.length & 4294967295) + " / " + d));
          this.m.push(b);
          this.c = h;
        }
        this.s = true;
        var v = this.m, s, F, H = 0, w = 0, z;
        s = 0;
        for (F = v.length; s < F; ++s) w += v[s].data.length;
        if (x) {
          z = new Uint8Array(w);
          for (s = 0; s < F; ++s) z.set(v[s].data, H), H += v[s].data.length;
        } else {
          z = [];
          for (s = 0; s < F; ++s) z[s] = v[s].data;
          z = Array.prototype.concat.apply([], z);
        }
        return z;
      };
      t("Zlib.Gunzip", $);
      t("Zlib.Gunzip.prototype.decompress", $.prototype.g);
      t("Zlib.Gunzip.prototype.getMembers", $.prototype.F);
      t("Zlib.GunzipMember", E);
      t("Zlib.GunzipMember.prototype.getName", E.prototype.getName);
      t("Zlib.GunzipMember.prototype.getData", E.prototype.getData);
      t("Zlib.GunzipMember.prototype.getMtime", E.prototype.G);
    }).call(gunzip_min);
    return gunzip_min;
  }
  var pathBrowserify;
  var hasRequiredPathBrowserify;
  function requirePathBrowserify() {
    if (hasRequiredPathBrowserify) return pathBrowserify;
    hasRequiredPathBrowserify = 1;
    function assertPath(path) {
      if (typeof path !== "string") {
        throw new TypeError("Path must be a string. Received " + JSON.stringify(path));
      }
    }
    function normalizeStringPosix(path, allowAboveRoot) {
      var res = "";
      var lastSegmentLength = 0;
      var lastSlash = -1;
      var dots = 0;
      var code;
      for (var i = 0; i <= path.length; ++i) {
        if (i < path.length)
          code = path.charCodeAt(i);
        else if (code === 47)
          break;
        else
          code = 47;
        if (code === 47) {
          if (lastSlash === i - 1 || dots === 1) ;
          else if (lastSlash !== i - 1 && dots === 2) {
            if (res.length < 2 || lastSegmentLength !== 2 || res.charCodeAt(res.length - 1) !== 46 || res.charCodeAt(res.length - 2) !== 46) {
              if (res.length > 2) {
                var lastSlashIndex = res.lastIndexOf("/");
                if (lastSlashIndex !== res.length - 1) {
                  if (lastSlashIndex === -1) {
                    res = "";
                    lastSegmentLength = 0;
                  } else {
                    res = res.slice(0, lastSlashIndex);
                    lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
                  }
                  lastSlash = i;
                  dots = 0;
                  continue;
                }
              } else if (res.length === 2 || res.length === 1) {
                res = "";
                lastSegmentLength = 0;
                lastSlash = i;
                dots = 0;
                continue;
              }
            }
            if (allowAboveRoot) {
              if (res.length > 0)
                res += "/..";
              else
                res = "..";
              lastSegmentLength = 2;
            }
          } else {
            if (res.length > 0)
              res += "/" + path.slice(lastSlash + 1, i);
            else
              res = path.slice(lastSlash + 1, i);
            lastSegmentLength = i - lastSlash - 1;
          }
          lastSlash = i;
          dots = 0;
        } else if (code === 46 && dots !== -1) {
          ++dots;
        } else {
          dots = -1;
        }
      }
      return res;
    }
    function _format(sep, pathObject) {
      var dir = pathObject.dir || pathObject.root;
      var base = pathObject.base || (pathObject.name || "") + (pathObject.ext || "");
      if (!dir) {
        return base;
      }
      if (dir === pathObject.root) {
        return dir + base;
      }
      return dir + sep + base;
    }
    var posix = {
      // path.resolve([from ...], to)
      resolve: function resolve() {
        var resolvedPath = "";
        var resolvedAbsolute = false;
        var cwd;
        for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
          var path;
          if (i >= 0)
            path = arguments[i];
          else {
            if (cwd === void 0)
              cwd = process.cwd();
            path = cwd;
          }
          assertPath(path);
          if (path.length === 0) {
            continue;
          }
          resolvedPath = path + "/" + resolvedPath;
          resolvedAbsolute = path.charCodeAt(0) === 47;
        }
        resolvedPath = normalizeStringPosix(resolvedPath, !resolvedAbsolute);
        if (resolvedAbsolute) {
          if (resolvedPath.length > 0)
            return "/" + resolvedPath;
          else
            return "/";
        } else if (resolvedPath.length > 0) {
          return resolvedPath;
        } else {
          return ".";
        }
      },
      normalize: function normalize(path) {
        assertPath(path);
        if (path.length === 0) return ".";
        var isAbsolute = path.charCodeAt(0) === 47;
        var trailingSeparator = path.charCodeAt(path.length - 1) === 47;
        path = normalizeStringPosix(path, !isAbsolute);
        if (path.length === 0 && !isAbsolute) path = ".";
        if (path.length > 0 && trailingSeparator) path += "/";
        if (isAbsolute) return "/" + path;
        return path;
      },
      isAbsolute: function isAbsolute(path) {
        assertPath(path);
        return path.length > 0 && path.charCodeAt(0) === 47;
      },
      join: function join() {
        if (arguments.length === 0)
          return ".";
        var joined;
        for (var i = 0; i < arguments.length; ++i) {
          var arg = arguments[i];
          assertPath(arg);
          if (arg.length > 0) {
            if (joined === void 0)
              joined = arg;
            else
              joined += "/" + arg;
          }
        }
        if (joined === void 0)
          return ".";
        return posix.normalize(joined);
      },
      relative: function relative(from, to) {
        assertPath(from);
        assertPath(to);
        if (from === to) return "";
        from = posix.resolve(from);
        to = posix.resolve(to);
        if (from === to) return "";
        var fromStart = 1;
        for (; fromStart < from.length; ++fromStart) {
          if (from.charCodeAt(fromStart) !== 47)
            break;
        }
        var fromEnd = from.length;
        var fromLen = fromEnd - fromStart;
        var toStart = 1;
        for (; toStart < to.length; ++toStart) {
          if (to.charCodeAt(toStart) !== 47)
            break;
        }
        var toEnd = to.length;
        var toLen = toEnd - toStart;
        var length = fromLen < toLen ? fromLen : toLen;
        var lastCommonSep = -1;
        var i = 0;
        for (; i <= length; ++i) {
          if (i === length) {
            if (toLen > length) {
              if (to.charCodeAt(toStart + i) === 47) {
                return to.slice(toStart + i + 1);
              } else if (i === 0) {
                return to.slice(toStart + i);
              }
            } else if (fromLen > length) {
              if (from.charCodeAt(fromStart + i) === 47) {
                lastCommonSep = i;
              } else if (i === 0) {
                lastCommonSep = 0;
              }
            }
            break;
          }
          var fromCode = from.charCodeAt(fromStart + i);
          var toCode = to.charCodeAt(toStart + i);
          if (fromCode !== toCode)
            break;
          else if (fromCode === 47)
            lastCommonSep = i;
        }
        var out = "";
        for (i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i) {
          if (i === fromEnd || from.charCodeAt(i) === 47) {
            if (out.length === 0)
              out += "..";
            else
              out += "/..";
          }
        }
        if (out.length > 0)
          return out + to.slice(toStart + lastCommonSep);
        else {
          toStart += lastCommonSep;
          if (to.charCodeAt(toStart) === 47)
            ++toStart;
          return to.slice(toStart);
        }
      },
      _makeLong: function _makeLong(path) {
        return path;
      },
      dirname: function dirname(path) {
        assertPath(path);
        if (path.length === 0) return ".";
        var code = path.charCodeAt(0);
        var hasRoot = code === 47;
        var end = -1;
        var matchedSlash = true;
        for (var i = path.length - 1; i >= 1; --i) {
          code = path.charCodeAt(i);
          if (code === 47) {
            if (!matchedSlash) {
              end = i;
              break;
            }
          } else {
            matchedSlash = false;
          }
        }
        if (end === -1) return hasRoot ? "/" : ".";
        if (hasRoot && end === 1) return "//";
        return path.slice(0, end);
      },
      basename: function basename(path, ext) {
        if (ext !== void 0 && typeof ext !== "string") throw new TypeError('"ext" argument must be a string');
        assertPath(path);
        var start = 0;
        var end = -1;
        var matchedSlash = true;
        var i;
        if (ext !== void 0 && ext.length > 0 && ext.length <= path.length) {
          if (ext.length === path.length && ext === path) return "";
          var extIdx = ext.length - 1;
          var firstNonSlashEnd = -1;
          for (i = path.length - 1; i >= 0; --i) {
            var code = path.charCodeAt(i);
            if (code === 47) {
              if (!matchedSlash) {
                start = i + 1;
                break;
              }
            } else {
              if (firstNonSlashEnd === -1) {
                matchedSlash = false;
                firstNonSlashEnd = i + 1;
              }
              if (extIdx >= 0) {
                if (code === ext.charCodeAt(extIdx)) {
                  if (--extIdx === -1) {
                    end = i;
                  }
                } else {
                  extIdx = -1;
                  end = firstNonSlashEnd;
                }
              }
            }
          }
          if (start === end) end = firstNonSlashEnd;
          else if (end === -1) end = path.length;
          return path.slice(start, end);
        } else {
          for (i = path.length - 1; i >= 0; --i) {
            if (path.charCodeAt(i) === 47) {
              if (!matchedSlash) {
                start = i + 1;
                break;
              }
            } else if (end === -1) {
              matchedSlash = false;
              end = i + 1;
            }
          }
          if (end === -1) return "";
          return path.slice(start, end);
        }
      },
      extname: function extname(path) {
        assertPath(path);
        var startDot = -1;
        var startPart = 0;
        var end = -1;
        var matchedSlash = true;
        var preDotState = 0;
        for (var i = path.length - 1; i >= 0; --i) {
          var code = path.charCodeAt(i);
          if (code === 47) {
            if (!matchedSlash) {
              startPart = i + 1;
              break;
            }
            continue;
          }
          if (end === -1) {
            matchedSlash = false;
            end = i + 1;
          }
          if (code === 46) {
            if (startDot === -1)
              startDot = i;
            else if (preDotState !== 1)
              preDotState = 1;
          } else if (startDot !== -1) {
            preDotState = -1;
          }
        }
        if (startDot === -1 || end === -1 || // We saw a non-dot character immediately before the dot
        preDotState === 0 || // The (right-most) trimmed path component is exactly '..'
        preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
          return "";
        }
        return path.slice(startDot, end);
      },
      format: function format(pathObject) {
        if (pathObject === null || typeof pathObject !== "object") {
          throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof pathObject);
        }
        return _format("/", pathObject);
      },
      parse: function parse(path) {
        assertPath(path);
        var ret = { root: "", dir: "", base: "", ext: "", name: "" };
        if (path.length === 0) return ret;
        var code = path.charCodeAt(0);
        var isAbsolute = code === 47;
        var start;
        if (isAbsolute) {
          ret.root = "/";
          start = 1;
        } else {
          start = 0;
        }
        var startDot = -1;
        var startPart = 0;
        var end = -1;
        var matchedSlash = true;
        var i = path.length - 1;
        var preDotState = 0;
        for (; i >= start; --i) {
          code = path.charCodeAt(i);
          if (code === 47) {
            if (!matchedSlash) {
              startPart = i + 1;
              break;
            }
            continue;
          }
          if (end === -1) {
            matchedSlash = false;
            end = i + 1;
          }
          if (code === 46) {
            if (startDot === -1) startDot = i;
            else if (preDotState !== 1) preDotState = 1;
          } else if (startDot !== -1) {
            preDotState = -1;
          }
        }
        if (startDot === -1 || end === -1 || // We saw a non-dot character immediately before the dot
        preDotState === 0 || // The (right-most) trimmed path component is exactly '..'
        preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
          if (end !== -1) {
            if (startPart === 0 && isAbsolute) ret.base = ret.name = path.slice(1, end);
            else ret.base = ret.name = path.slice(startPart, end);
          }
        } else {
          if (startPart === 0 && isAbsolute) {
            ret.name = path.slice(1, startDot);
            ret.base = path.slice(1, end);
          } else {
            ret.name = path.slice(startPart, startDot);
            ret.base = path.slice(startPart, end);
          }
          ret.ext = path.slice(startDot, end);
        }
        if (startPart > 0) ret.dir = path.slice(0, startPart - 1);
        else if (isAbsolute) ret.dir = "/";
        return ret;
      },
      sep: "/",
      delimiter: ":",
      win32: null,
      posix: null
    };
    posix.posix = posix;
    pathBrowserify = posix;
    return pathBrowserify;
  }
  var async$1 = { exports: {} };
  var async = async$1.exports;
  var hasRequiredAsync;
  function requireAsync() {
    if (hasRequiredAsync) return async$1.exports;
    hasRequiredAsync = 1;
    (function(module2, exports$1) {
      (function(global2, factory) {
        factory(exports$1);
      })(async, (function(exports$12) {
        function slice(arrayLike, start) {
          start = start | 0;
          var newLen = Math.max(arrayLike.length - start, 0);
          var newArr = Array(newLen);
          for (var idx = 0; idx < newLen; idx++) {
            newArr[idx] = arrayLike[start + idx];
          }
          return newArr;
        }
        var apply = function(fn) {
          var args = slice(arguments, 1);
          return function() {
            var callArgs = slice(arguments);
            return fn.apply(null, args.concat(callArgs));
          };
        };
        var initialParams = function(fn) {
          return function() {
            var args = slice(arguments);
            var callback = args.pop();
            fn.call(this, args, callback);
          };
        };
        function isObject(value) {
          var type = typeof value;
          return value != null && (type == "object" || type == "function");
        }
        var hasSetImmediate = typeof setImmediate === "function" && setImmediate;
        var hasNextTick = typeof process === "object" && typeof process.nextTick === "function";
        function fallback(fn) {
          setTimeout(fn, 0);
        }
        function wrap(defer) {
          return function(fn) {
            var args = slice(arguments, 1);
            defer(function() {
              fn.apply(null, args);
            });
          };
        }
        var _defer;
        if (hasSetImmediate) {
          _defer = setImmediate;
        } else if (hasNextTick) {
          _defer = process.nextTick;
        } else {
          _defer = fallback;
        }
        var setImmediate$1 = wrap(_defer);
        function asyncify(func) {
          return initialParams(function(args, callback) {
            var result;
            try {
              result = func.apply(this, args);
            } catch (e) {
              return callback(e);
            }
            if (isObject(result) && typeof result.then === "function") {
              result.then(function(value) {
                invokeCallback(callback, null, value);
              }, function(err) {
                invokeCallback(callback, err.message ? err : new Error(err));
              });
            } else {
              callback(null, result);
            }
          });
        }
        function invokeCallback(callback, error, value) {
          try {
            callback(error, value);
          } catch (e) {
            setImmediate$1(rethrow, e);
          }
        }
        function rethrow(error) {
          throw error;
        }
        var supportsSymbol = typeof Symbol === "function";
        function isAsync(fn) {
          return supportsSymbol && fn[Symbol.toStringTag] === "AsyncFunction";
        }
        function wrapAsync(asyncFn) {
          return isAsync(asyncFn) ? asyncify(asyncFn) : asyncFn;
        }
        function applyEach$1(eachfn) {
          return function(fns) {
            var args = slice(arguments, 1);
            var go = initialParams(function(args2, callback) {
              var that = this;
              return eachfn(fns, function(fn, cb) {
                wrapAsync(fn).apply(that, args2.concat(cb));
              }, callback);
            });
            if (args.length) {
              return go.apply(this, args);
            } else {
              return go;
            }
          };
        }
        var freeGlobal = typeof commonjsGlobal == "object" && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;
        var freeSelf = typeof self == "object" && self && self.Object === Object && self;
        var root = freeGlobal || freeSelf || Function("return this")();
        var Symbol$1 = root.Symbol;
        var objectProto = Object.prototype;
        var hasOwnProperty = objectProto.hasOwnProperty;
        var nativeObjectToString = objectProto.toString;
        var symToStringTag$1 = Symbol$1 ? Symbol$1.toStringTag : void 0;
        function getRawTag(value) {
          var isOwn = hasOwnProperty.call(value, symToStringTag$1), tag = value[symToStringTag$1];
          try {
            value[symToStringTag$1] = void 0;
            var unmasked = true;
          } catch (e) {
          }
          var result = nativeObjectToString.call(value);
          if (unmasked) {
            if (isOwn) {
              value[symToStringTag$1] = tag;
            } else {
              delete value[symToStringTag$1];
            }
          }
          return result;
        }
        var objectProto$1 = Object.prototype;
        var nativeObjectToString$1 = objectProto$1.toString;
        function objectToString(value) {
          return nativeObjectToString$1.call(value);
        }
        var nullTag = "[object Null]";
        var undefinedTag = "[object Undefined]";
        var symToStringTag = Symbol$1 ? Symbol$1.toStringTag : void 0;
        function baseGetTag(value) {
          if (value == null) {
            return value === void 0 ? undefinedTag : nullTag;
          }
          return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
        }
        var asyncTag = "[object AsyncFunction]";
        var funcTag = "[object Function]";
        var genTag = "[object GeneratorFunction]";
        var proxyTag = "[object Proxy]";
        function isFunction(value) {
          if (!isObject(value)) {
            return false;
          }
          var tag = baseGetTag(value);
          return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
        }
        var MAX_SAFE_INTEGER = 9007199254740991;
        function isLength(value) {
          return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
        }
        function isArrayLike(value) {
          return value != null && isLength(value.length) && !isFunction(value);
        }
        var breakLoop = {};
        function noop() {
        }
        function once(fn) {
          return function() {
            if (fn === null) return;
            var callFn = fn;
            fn = null;
            callFn.apply(this, arguments);
          };
        }
        var iteratorSymbol = typeof Symbol === "function" && Symbol.iterator;
        var getIterator = function(coll) {
          return iteratorSymbol && coll[iteratorSymbol] && coll[iteratorSymbol]();
        };
        function baseTimes(n, iteratee) {
          var index2 = -1, result = Array(n);
          while (++index2 < n) {
            result[index2] = iteratee(index2);
          }
          return result;
        }
        function isObjectLike(value) {
          return value != null && typeof value == "object";
        }
        var argsTag = "[object Arguments]";
        function baseIsArguments(value) {
          return isObjectLike(value) && baseGetTag(value) == argsTag;
        }
        var objectProto$3 = Object.prototype;
        var hasOwnProperty$2 = objectProto$3.hasOwnProperty;
        var propertyIsEnumerable = objectProto$3.propertyIsEnumerable;
        var isArguments = baseIsArguments(/* @__PURE__ */ (function() {
          return arguments;
        })()) ? baseIsArguments : function(value) {
          return isObjectLike(value) && hasOwnProperty$2.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
        };
        var isArray = Array.isArray;
        function stubFalse() {
          return false;
        }
        var freeExports = typeof exports$12 == "object" && exports$12 && !exports$12.nodeType && exports$12;
        var freeModule = freeExports && true && module2 && !module2.nodeType && module2;
        var moduleExports = freeModule && freeModule.exports === freeExports;
        var Buffer = moduleExports ? root.Buffer : void 0;
        var nativeIsBuffer = Buffer ? Buffer.isBuffer : void 0;
        var isBuffer = nativeIsBuffer || stubFalse;
        var MAX_SAFE_INTEGER$1 = 9007199254740991;
        var reIsUint = /^(?:0|[1-9]\d*)$/;
        function isIndex(value, length) {
          var type = typeof value;
          length = length == null ? MAX_SAFE_INTEGER$1 : length;
          return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
        }
        var argsTag$1 = "[object Arguments]";
        var arrayTag = "[object Array]";
        var boolTag = "[object Boolean]";
        var dateTag = "[object Date]";
        var errorTag = "[object Error]";
        var funcTag$1 = "[object Function]";
        var mapTag = "[object Map]";
        var numberTag = "[object Number]";
        var objectTag = "[object Object]";
        var regexpTag = "[object RegExp]";
        var setTag = "[object Set]";
        var stringTag = "[object String]";
        var weakMapTag = "[object WeakMap]";
        var arrayBufferTag = "[object ArrayBuffer]";
        var dataViewTag = "[object DataView]";
        var float32Tag = "[object Float32Array]";
        var float64Tag = "[object Float64Array]";
        var int8Tag = "[object Int8Array]";
        var int16Tag = "[object Int16Array]";
        var int32Tag = "[object Int32Array]";
        var uint8Tag = "[object Uint8Array]";
        var uint8ClampedTag = "[object Uint8ClampedArray]";
        var uint16Tag = "[object Uint16Array]";
        var uint32Tag = "[object Uint32Array]";
        var typedArrayTags = {};
        typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
        typedArrayTags[argsTag$1] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag$1] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
        function baseIsTypedArray(value) {
          return isObjectLike(value) && isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
        }
        function baseUnary(func) {
          return function(value) {
            return func(value);
          };
        }
        var freeExports$1 = typeof exports$12 == "object" && exports$12 && !exports$12.nodeType && exports$12;
        var freeModule$1 = freeExports$1 && true && module2 && !module2.nodeType && module2;
        var moduleExports$1 = freeModule$1 && freeModule$1.exports === freeExports$1;
        var freeProcess = moduleExports$1 && freeGlobal.process;
        var nodeUtil = (function() {
          try {
            var types = freeModule$1 && freeModule$1.require && freeModule$1.require("util").types;
            if (types) {
              return types;
            }
            return freeProcess && freeProcess.binding && freeProcess.binding("util");
          } catch (e) {
          }
        })();
        var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;
        var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;
        var objectProto$2 = Object.prototype;
        var hasOwnProperty$1 = objectProto$2.hasOwnProperty;
        function arrayLikeKeys(value, inherited) {
          var isArr = isArray(value), isArg = !isArr && isArguments(value), isBuff = !isArr && !isArg && isBuffer(value), isType = !isArr && !isArg && !isBuff && isTypedArray(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes(value.length, String) : [], length = result.length;
          for (var key in value) {
            if (hasOwnProperty$1.call(value, key) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
            (key == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
            isBuff && (key == "offset" || key == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
            isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || // Skip index properties.
            isIndex(key, length)))) {
              result.push(key);
            }
          }
          return result;
        }
        var objectProto$5 = Object.prototype;
        function isPrototype(value) {
          var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto$5;
          return value === proto;
        }
        function overArg(func, transform2) {
          return function(arg) {
            return func(transform2(arg));
          };
        }
        var nativeKeys = overArg(Object.keys, Object);
        var objectProto$4 = Object.prototype;
        var hasOwnProperty$3 = objectProto$4.hasOwnProperty;
        function baseKeys(object) {
          if (!isPrototype(object)) {
            return nativeKeys(object);
          }
          var result = [];
          for (var key in Object(object)) {
            if (hasOwnProperty$3.call(object, key) && key != "constructor") {
              result.push(key);
            }
          }
          return result;
        }
        function keys(object) {
          return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
        }
        function createArrayIterator(coll) {
          var i = -1;
          var len = coll.length;
          return function next() {
            return ++i < len ? { value: coll[i], key: i } : null;
          };
        }
        function createES2015Iterator(iterator2) {
          var i = -1;
          return function next() {
            var item = iterator2.next();
            if (item.done)
              return null;
            i++;
            return { value: item.value, key: i };
          };
        }
        function createObjectIterator(obj) {
          var okeys = keys(obj);
          var i = -1;
          var len = okeys.length;
          return function next() {
            var key = okeys[++i];
            if (key === "__proto__") {
              return next();
            }
            return i < len ? { value: obj[key], key } : null;
          };
        }
        function iterator(coll) {
          if (isArrayLike(coll)) {
            return createArrayIterator(coll);
          }
          var iterator2 = getIterator(coll);
          return iterator2 ? createES2015Iterator(iterator2) : createObjectIterator(coll);
        }
        function onlyOnce(fn) {
          return function() {
            if (fn === null) throw new Error("Callback was already called.");
            var callFn = fn;
            fn = null;
            callFn.apply(this, arguments);
          };
        }
        function _eachOfLimit(limit) {
          return function(obj, iteratee, callback) {
            callback = once(callback || noop);
            if (limit <= 0 || !obj) {
              return callback(null);
            }
            var nextElem = iterator(obj);
            var done = false;
            var running = 0;
            var looping = false;
            function iterateeCallback(err, value) {
              running -= 1;
              if (err) {
                done = true;
                callback(err);
              } else if (value === breakLoop || done && running <= 0) {
                done = true;
                return callback(null);
              } else if (!looping) {
                replenish();
              }
            }
            function replenish() {
              looping = true;
              while (running < limit && !done) {
                var elem = nextElem();
                if (elem === null) {
                  done = true;
                  if (running <= 0) {
                    callback(null);
                  }
                  return;
                }
                running += 1;
                iteratee(elem.value, elem.key, onlyOnce(iterateeCallback));
              }
              looping = false;
            }
            replenish();
          };
        }
        function eachOfLimit(coll, limit, iteratee, callback) {
          _eachOfLimit(limit)(coll, wrapAsync(iteratee), callback);
        }
        function doLimit(fn, limit) {
          return function(iterable, iteratee, callback) {
            return fn(iterable, limit, iteratee, callback);
          };
        }
        function eachOfArrayLike(coll, iteratee, callback) {
          callback = once(callback || noop);
          var index2 = 0, completed = 0, length = coll.length;
          if (length === 0) {
            callback(null);
          }
          function iteratorCallback(err, value) {
            if (err) {
              callback(err);
            } else if (++completed === length || value === breakLoop) {
              callback(null);
            }
          }
          for (; index2 < length; index2++) {
            iteratee(coll[index2], index2, onlyOnce(iteratorCallback));
          }
        }
        var eachOfGeneric = doLimit(eachOfLimit, Infinity);
        var eachOf = function(coll, iteratee, callback) {
          var eachOfImplementation = isArrayLike(coll) ? eachOfArrayLike : eachOfGeneric;
          eachOfImplementation(coll, wrapAsync(iteratee), callback);
        };
        function doParallel(fn) {
          return function(obj, iteratee, callback) {
            return fn(eachOf, obj, wrapAsync(iteratee), callback);
          };
        }
        function _asyncMap(eachfn, arr, iteratee, callback) {
          callback = callback || noop;
          arr = arr || [];
          var results = [];
          var counter = 0;
          var _iteratee = wrapAsync(iteratee);
          eachfn(arr, function(value, _, callback2) {
            var index2 = counter++;
            _iteratee(value, function(err, v) {
              results[index2] = v;
              callback2(err);
            });
          }, function(err) {
            callback(err, results);
          });
        }
        var map = doParallel(_asyncMap);
        var applyEach = applyEach$1(map);
        function doParallelLimit(fn) {
          return function(obj, limit, iteratee, callback) {
            return fn(_eachOfLimit(limit), obj, wrapAsync(iteratee), callback);
          };
        }
        var mapLimit = doParallelLimit(_asyncMap);
        var mapSeries = doLimit(mapLimit, 1);
        var applyEachSeries = applyEach$1(mapSeries);
        function arrayEach(array, iteratee) {
          var index2 = -1, length = array == null ? 0 : array.length;
          while (++index2 < length) {
            if (iteratee(array[index2], index2, array) === false) {
              break;
            }
          }
          return array;
        }
        function createBaseFor(fromRight) {
          return function(object, iteratee, keysFunc) {
            var index2 = -1, iterable = Object(object), props = keysFunc(object), length = props.length;
            while (length--) {
              var key = props[++index2];
              if (iteratee(iterable[key], key, iterable) === false) {
                break;
              }
            }
            return object;
          };
        }
        var baseFor = createBaseFor();
        function baseForOwn(object, iteratee) {
          return object && baseFor(object, iteratee, keys);
        }
        function baseFindIndex(array, predicate, fromIndex, fromRight) {
          var length = array.length, index2 = fromIndex + -1;
          while (++index2 < length) {
            if (predicate(array[index2], index2, array)) {
              return index2;
            }
          }
          return -1;
        }
        function baseIsNaN(value) {
          return value !== value;
        }
        function strictIndexOf(array, value, fromIndex) {
          var index2 = fromIndex - 1, length = array.length;
          while (++index2 < length) {
            if (array[index2] === value) {
              return index2;
            }
          }
          return -1;
        }
        function baseIndexOf(array, value, fromIndex) {
          return value === value ? strictIndexOf(array, value, fromIndex) : baseFindIndex(array, baseIsNaN, fromIndex);
        }
        var auto = function(tasks, concurrency, callback) {
          if (typeof concurrency === "function") {
            callback = concurrency;
            concurrency = null;
          }
          callback = once(callback || noop);
          var keys$$1 = keys(tasks);
          var numTasks = keys$$1.length;
          if (!numTasks) {
            return callback(null);
          }
          if (!concurrency) {
            concurrency = numTasks;
          }
          var results = {};
          var runningTasks = 0;
          var hasError = false;
          var listeners = /* @__PURE__ */ Object.create(null);
          var readyTasks = [];
          var readyToCheck = [];
          var uncheckedDependencies = {};
          baseForOwn(tasks, function(task, key) {
            if (!isArray(task)) {
              enqueueTask(key, [task]);
              readyToCheck.push(key);
              return;
            }
            var dependencies = task.slice(0, task.length - 1);
            var remainingDependencies = dependencies.length;
            if (remainingDependencies === 0) {
              enqueueTask(key, task);
              readyToCheck.push(key);
              return;
            }
            uncheckedDependencies[key] = remainingDependencies;
            arrayEach(dependencies, function(dependencyName) {
              if (!tasks[dependencyName]) {
                throw new Error("async.auto task `" + key + "` has a non-existent dependency `" + dependencyName + "` in " + dependencies.join(", "));
              }
              addListener(dependencyName, function() {
                remainingDependencies--;
                if (remainingDependencies === 0) {
                  enqueueTask(key, task);
                }
              });
            });
          });
          checkForDeadlocks();
          processQueue();
          function enqueueTask(key, task) {
            readyTasks.push(function() {
              runTask(key, task);
            });
          }
          function processQueue() {
            if (readyTasks.length === 0 && runningTasks === 0) {
              return callback(null, results);
            }
            while (readyTasks.length && runningTasks < concurrency) {
              var run = readyTasks.shift();
              run();
            }
          }
          function addListener(taskName, fn) {
            var taskListeners = listeners[taskName];
            if (!taskListeners) {
              taskListeners = listeners[taskName] = [];
            }
            taskListeners.push(fn);
          }
          function taskComplete(taskName) {
            var taskListeners = listeners[taskName] || [];
            arrayEach(taskListeners, function(fn) {
              fn();
            });
            processQueue();
          }
          function runTask(key, task) {
            if (hasError) return;
            var taskCallback = onlyOnce(function(err, result) {
              runningTasks--;
              if (arguments.length > 2) {
                result = slice(arguments, 1);
              }
              if (err) {
                var safeResults = {};
                baseForOwn(results, function(val, rkey) {
                  safeResults[rkey] = val;
                });
                safeResults[key] = result;
                hasError = true;
                listeners = /* @__PURE__ */ Object.create(null);
                callback(err, safeResults);
              } else {
                results[key] = result;
                taskComplete(key);
              }
            });
            runningTasks++;
            var taskFn = wrapAsync(task[task.length - 1]);
            if (task.length > 1) {
              taskFn(results, taskCallback);
            } else {
              taskFn(taskCallback);
            }
          }
          function checkForDeadlocks() {
            var currentTask;
            var counter = 0;
            while (readyToCheck.length) {
              currentTask = readyToCheck.pop();
              counter++;
              arrayEach(getDependents(currentTask), function(dependent) {
                if (--uncheckedDependencies[dependent] === 0) {
                  readyToCheck.push(dependent);
                }
              });
            }
            if (counter !== numTasks) {
              throw new Error(
                "async.auto cannot execute tasks due to a recursive dependency"
              );
            }
          }
          function getDependents(taskName) {
            var result = [];
            baseForOwn(tasks, function(task, key) {
              if (isArray(task) && baseIndexOf(task, taskName, 0) >= 0) {
                result.push(key);
              }
            });
            return result;
          }
        };
        function arrayMap(array, iteratee) {
          var index2 = -1, length = array == null ? 0 : array.length, result = Array(length);
          while (++index2 < length) {
            result[index2] = iteratee(array[index2], index2, array);
          }
          return result;
        }
        var symbolTag = "[object Symbol]";
        function isSymbol(value) {
          return typeof value == "symbol" || isObjectLike(value) && baseGetTag(value) == symbolTag;
        }
        var symbolProto = Symbol$1 ? Symbol$1.prototype : void 0;
        var symbolToString = symbolProto ? symbolProto.toString : void 0;
        function baseToString(value) {
          if (typeof value == "string") {
            return value;
          }
          if (isArray(value)) {
            return arrayMap(value, baseToString) + "";
          }
          if (isSymbol(value)) {
            return symbolToString ? symbolToString.call(value) : "";
          }
          var result = value + "";
          return result == "0" && 1 / value == -Infinity ? "-0" : result;
        }
        function baseSlice(array, start, end) {
          var index2 = -1, length = array.length;
          if (start < 0) {
            start = -start > length ? 0 : length + start;
          }
          end = end > length ? length : end;
          if (end < 0) {
            end += length;
          }
          length = start > end ? 0 : end - start >>> 0;
          start >>>= 0;
          var result = Array(length);
          while (++index2 < length) {
            result[index2] = array[index2 + start];
          }
          return result;
        }
        function castSlice(array, start, end) {
          var length = array.length;
          end = end === void 0 ? length : end;
          return !start && end >= length ? array : baseSlice(array, start, end);
        }
        function charsEndIndex(strSymbols, chrSymbols) {
          var index2 = strSymbols.length;
          while (index2-- && baseIndexOf(chrSymbols, strSymbols[index2], 0) > -1) {
          }
          return index2;
        }
        function charsStartIndex(strSymbols, chrSymbols) {
          var index2 = -1, length = strSymbols.length;
          while (++index2 < length && baseIndexOf(chrSymbols, strSymbols[index2], 0) > -1) {
          }
          return index2;
        }
        function asciiToArray(string) {
          return string.split("");
        }
        var rsAstralRange = "\\ud800-\\udfff";
        var rsComboMarksRange = "\\u0300-\\u036f";
        var reComboHalfMarksRange = "\\ufe20-\\ufe2f";
        var rsComboSymbolsRange = "\\u20d0-\\u20ff";
        var rsComboRange = rsComboMarksRange + reComboHalfMarksRange + rsComboSymbolsRange;
        var rsVarRange = "\\ufe0e\\ufe0f";
        var rsZWJ = "\\u200d";
        var reHasUnicode = RegExp("[" + rsZWJ + rsAstralRange + rsComboRange + rsVarRange + "]");
        function hasUnicode(string) {
          return reHasUnicode.test(string);
        }
        var rsAstralRange$1 = "\\ud800-\\udfff";
        var rsComboMarksRange$1 = "\\u0300-\\u036f";
        var reComboHalfMarksRange$1 = "\\ufe20-\\ufe2f";
        var rsComboSymbolsRange$1 = "\\u20d0-\\u20ff";
        var rsComboRange$1 = rsComboMarksRange$1 + reComboHalfMarksRange$1 + rsComboSymbolsRange$1;
        var rsVarRange$1 = "\\ufe0e\\ufe0f";
        var rsAstral = "[" + rsAstralRange$1 + "]";
        var rsCombo = "[" + rsComboRange$1 + "]";
        var rsFitz = "\\ud83c[\\udffb-\\udfff]";
        var rsModifier = "(?:" + rsCombo + "|" + rsFitz + ")";
        var rsNonAstral = "[^" + rsAstralRange$1 + "]";
        var rsRegional = "(?:\\ud83c[\\udde6-\\uddff]){2}";
        var rsSurrPair = "[\\ud800-\\udbff][\\udc00-\\udfff]";
        var rsZWJ$1 = "\\u200d";
        var reOptMod = rsModifier + "?";
        var rsOptVar = "[" + rsVarRange$1 + "]?";
        var rsOptJoin = "(?:" + rsZWJ$1 + "(?:" + [rsNonAstral, rsRegional, rsSurrPair].join("|") + ")" + rsOptVar + reOptMod + ")*";
        var rsSeq = rsOptVar + reOptMod + rsOptJoin;
        var rsSymbol = "(?:" + [rsNonAstral + rsCombo + "?", rsCombo, rsRegional, rsSurrPair, rsAstral].join("|") + ")";
        var reUnicode = RegExp(rsFitz + "(?=" + rsFitz + ")|" + rsSymbol + rsSeq, "g");
        function unicodeToArray(string) {
          return string.match(reUnicode) || [];
        }
        function stringToArray(string) {
          return hasUnicode(string) ? unicodeToArray(string) : asciiToArray(string);
        }
        function toString(value) {
          return value == null ? "" : baseToString(value);
        }
        var reTrim = /^\s+|\s+$/g;
        function trim(string, chars, guard) {
          string = toString(string);
          if (string && chars === void 0) {
            return string.replace(reTrim, "");
          }
          if (!string || !(chars = baseToString(chars))) {
            return string;
          }
          var strSymbols = stringToArray(string), chrSymbols = stringToArray(chars), start = charsStartIndex(strSymbols, chrSymbols), end = charsEndIndex(strSymbols, chrSymbols) + 1;
          return castSlice(strSymbols, start, end).join("");
        }
        var FN_ARGS = /^(?:async\s+)?(function)?\s*[^\(]*\(\s*([^\)]*)\)/m;
        var FN_ARG_SPLIT = /,/;
        var FN_ARG = /(=.+)?(\s*)$/;
        var STRIP_COMMENTS = /((\/\/.*$)|(\/\*[\s\S]*?\*\/))/mg;
        function parseParams(func) {
          func = func.toString().replace(STRIP_COMMENTS, "");
          func = func.match(FN_ARGS)[2].replace(" ", "");
          func = func ? func.split(FN_ARG_SPLIT) : [];
          func = func.map(function(arg) {
            return trim(arg.replace(FN_ARG, ""));
          });
          return func;
        }
        function autoInject(tasks, callback) {
          var newTasks = {};
          baseForOwn(tasks, function(taskFn, key) {
            var params;
            var fnIsAsync = isAsync(taskFn);
            var hasNoDeps = !fnIsAsync && taskFn.length === 1 || fnIsAsync && taskFn.length === 0;
            if (isArray(taskFn)) {
              params = taskFn.slice(0, -1);
              taskFn = taskFn[taskFn.length - 1];
              newTasks[key] = params.concat(params.length > 0 ? newTask : taskFn);
            } else if (hasNoDeps) {
              newTasks[key] = taskFn;
            } else {
              params = parseParams(taskFn);
              if (taskFn.length === 0 && !fnIsAsync && params.length === 0) {
                throw new Error("autoInject task functions require explicit parameters.");
              }
              if (!fnIsAsync) params.pop();
              newTasks[key] = params.concat(newTask);
            }
            function newTask(results, taskCb) {
              var newArgs = arrayMap(params, function(name) {
                return results[name];
              });
              newArgs.push(taskCb);
              wrapAsync(taskFn).apply(null, newArgs);
            }
          });
          auto(newTasks, callback);
        }
        function DLL() {
          this.head = this.tail = null;
          this.length = 0;
        }
        function setInitial(dll, node) {
          dll.length = 1;
          dll.head = dll.tail = node;
        }
        DLL.prototype.removeLink = function(node) {
          if (node.prev) node.prev.next = node.next;
          else this.head = node.next;
          if (node.next) node.next.prev = node.prev;
          else this.tail = node.prev;
          node.prev = node.next = null;
          this.length -= 1;
          return node;
        };
        DLL.prototype.empty = function() {
          while (this.head) this.shift();
          return this;
        };
        DLL.prototype.insertAfter = function(node, newNode) {
          newNode.prev = node;
          newNode.next = node.next;
          if (node.next) node.next.prev = newNode;
          else this.tail = newNode;
          node.next = newNode;
          this.length += 1;
        };
        DLL.prototype.insertBefore = function(node, newNode) {
          newNode.prev = node.prev;
          newNode.next = node;
          if (node.prev) node.prev.next = newNode;
          else this.head = newNode;
          node.prev = newNode;
          this.length += 1;
        };
        DLL.prototype.unshift = function(node) {
          if (this.head) this.insertBefore(this.head, node);
          else setInitial(this, node);
        };
        DLL.prototype.push = function(node) {
          if (this.tail) this.insertAfter(this.tail, node);
          else setInitial(this, node);
        };
        DLL.prototype.shift = function() {
          return this.head && this.removeLink(this.head);
        };
        DLL.prototype.pop = function() {
          return this.tail && this.removeLink(this.tail);
        };
        DLL.prototype.toArray = function() {
          var arr = Array(this.length);
          var curr = this.head;
          for (var idx = 0; idx < this.length; idx++) {
            arr[idx] = curr.data;
            curr = curr.next;
          }
          return arr;
        };
        DLL.prototype.remove = function(testFn) {
          var curr = this.head;
          while (!!curr) {
            var next = curr.next;
            if (testFn(curr)) {
              this.removeLink(curr);
            }
            curr = next;
          }
          return this;
        };
        function queue(worker, concurrency, payload) {
          if (concurrency == null) {
            concurrency = 1;
          } else if (concurrency === 0) {
            throw new Error("Concurrency must not be zero");
          }
          var _worker = wrapAsync(worker);
          var numRunning = 0;
          var workersList = [];
          var processingScheduled = false;
          function _insert(data, insertAtFront, callback) {
            if (callback != null && typeof callback !== "function") {
              throw new Error("task callback must be a function");
            }
            q.started = true;
            if (!isArray(data)) {
              data = [data];
            }
            if (data.length === 0 && q.idle()) {
              return setImmediate$1(function() {
                q.drain();
              });
            }
            for (var i = 0, l = data.length; i < l; i++) {
              var item = {
                data: data[i],
                callback: callback || noop
              };
              if (insertAtFront) {
                q._tasks.unshift(item);
              } else {
                q._tasks.push(item);
              }
            }
            if (!processingScheduled) {
              processingScheduled = true;
              setImmediate$1(function() {
                processingScheduled = false;
                q.process();
              });
            }
          }
          function _next(tasks) {
            return function(err) {
              numRunning -= 1;
              for (var i = 0, l = tasks.length; i < l; i++) {
                var task = tasks[i];
                var index2 = baseIndexOf(workersList, task, 0);
                if (index2 === 0) {
                  workersList.shift();
                } else if (index2 > 0) {
                  workersList.splice(index2, 1);
                }
                task.callback.apply(task, arguments);
                if (err != null) {
                  q.error(err, task.data);
                }
              }
              if (numRunning <= q.concurrency - q.buffer) {
                q.unsaturated();
              }
              if (q.idle()) {
                q.drain();
              }
              q.process();
            };
          }
          var isProcessing = false;
          var q = {
            _tasks: new DLL(),
            concurrency,
            payload,
            saturated: noop,
            unsaturated: noop,
            buffer: concurrency / 4,
            empty: noop,
            drain: noop,
            error: noop,
            started: false,
            paused: false,
            push: function(data, callback) {
              _insert(data, false, callback);
            },
            kill: function() {
              q.drain = noop;
              q._tasks.empty();
            },
            unshift: function(data, callback) {
              _insert(data, true, callback);
            },
            remove: function(testFn) {
              q._tasks.remove(testFn);
            },
            process: function() {
              if (isProcessing) {
                return;
              }
              isProcessing = true;
              while (!q.paused && numRunning < q.concurrency && q._tasks.length) {
                var tasks = [], data = [];
                var l = q._tasks.length;
                if (q.payload) l = Math.min(l, q.payload);
                for (var i = 0; i < l; i++) {
                  var node = q._tasks.shift();
                  tasks.push(node);
                  workersList.push(node);
                  data.push(node.data);
                }
                numRunning += 1;
                if (q._tasks.length === 0) {
                  q.empty();
                }
                if (numRunning === q.concurrency) {
                  q.saturated();
                }
                var cb = onlyOnce(_next(tasks));
                _worker(data, cb);
              }
              isProcessing = false;
            },
            length: function() {
              return q._tasks.length;
            },
            running: function() {
              return numRunning;
            },
            workersList: function() {
              return workersList;
            },
            idle: function() {
              return q._tasks.length + numRunning === 0;
            },
            pause: function() {
              q.paused = true;
            },
            resume: function() {
              if (q.paused === false) {
                return;
              }
              q.paused = false;
              setImmediate$1(q.process);
            }
          };
          return q;
        }
        function cargo(worker, payload) {
          return queue(worker, 1, payload);
        }
        var eachOfSeries = doLimit(eachOfLimit, 1);
        function reduce(coll, memo, iteratee, callback) {
          callback = once(callback || noop);
          var _iteratee = wrapAsync(iteratee);
          eachOfSeries(coll, function(x, i, callback2) {
            _iteratee(memo, x, function(err, v) {
              memo = v;
              callback2(err);
            });
          }, function(err) {
            callback(err, memo);
          });
        }
        function seq() {
          var _functions = arrayMap(arguments, wrapAsync);
          return function() {
            var args = slice(arguments);
            var that = this;
            var cb = args[args.length - 1];
            if (typeof cb == "function") {
              args.pop();
            } else {
              cb = noop;
            }
            reduce(
              _functions,
              args,
              function(newargs, fn, cb2) {
                fn.apply(that, newargs.concat(function(err) {
                  var nextargs = slice(arguments, 1);
                  cb2(err, nextargs);
                }));
              },
              function(err, results) {
                cb.apply(that, [err].concat(results));
              }
            );
          };
        }
        var compose = function() {
          return seq.apply(null, slice(arguments).reverse());
        };
        var _concat = Array.prototype.concat;
        var concatLimit = function(coll, limit, iteratee, callback) {
          callback = callback || noop;
          var _iteratee = wrapAsync(iteratee);
          mapLimit(coll, limit, function(val, callback2) {
            _iteratee(val, function(err) {
              if (err) return callback2(err);
              return callback2(null, slice(arguments, 1));
            });
          }, function(err, mapResults) {
            var result = [];
            for (var i = 0; i < mapResults.length; i++) {
              if (mapResults[i]) {
                result = _concat.apply(result, mapResults[i]);
              }
            }
            return callback(err, result);
          });
        };
        var concat = doLimit(concatLimit, Infinity);
        var concatSeries = doLimit(concatLimit, 1);
        var constant = function() {
          var values = slice(arguments);
          var args = [null].concat(values);
          return function() {
            var callback = arguments[arguments.length - 1];
            return callback.apply(this, args);
          };
        };
        function identity(value) {
          return value;
        }
        function _createTester(check, getResult) {
          return function(eachfn, arr, iteratee, cb) {
            cb = cb || noop;
            var testPassed = false;
            var testResult;
            eachfn(arr, function(value, _, callback) {
              iteratee(value, function(err, result) {
                if (err) {
                  callback(err);
                } else if (check(result) && !testResult) {
                  testPassed = true;
                  testResult = getResult(true, value);
                  callback(null, breakLoop);
                } else {
                  callback();
                }
              });
            }, function(err) {
              if (err) {
                cb(err);
              } else {
                cb(null, testPassed ? testResult : getResult(false));
              }
            });
          };
        }
        function _findGetResult(v, x) {
          return x;
        }
        var detect = doParallel(_createTester(identity, _findGetResult));
        var detectLimit = doParallelLimit(_createTester(identity, _findGetResult));
        var detectSeries = doLimit(detectLimit, 1);
        function consoleFunc(name) {
          return function(fn) {
            var args = slice(arguments, 1);
            args.push(function(err) {
              var args2 = slice(arguments, 1);
              if (typeof console === "object") {
                if (err) {
                  if (console.error) {
                    console.error(err);
                  }
                } else if (console[name]) {
                  arrayEach(args2, function(x) {
                    console[name](x);
                  });
                }
              }
            });
            wrapAsync(fn).apply(null, args);
          };
        }
        var dir = consoleFunc("dir");
        function doDuring(fn, test, callback) {
          callback = onlyOnce(callback || noop);
          var _fn = wrapAsync(fn);
          var _test = wrapAsync(test);
          function next(err) {
            if (err) return callback(err);
            var args = slice(arguments, 1);
            args.push(check);
            _test.apply(this, args);
          }
          function check(err, truth) {
            if (err) return callback(err);
            if (!truth) return callback(null);
            _fn(next);
          }
          check(null, true);
        }
        function doWhilst(iteratee, test, callback) {
          callback = onlyOnce(callback || noop);
          var _iteratee = wrapAsync(iteratee);
          var next = function(err) {
            if (err) return callback(err);
            var args = slice(arguments, 1);
            if (test.apply(this, args)) return _iteratee(next);
            callback.apply(null, [null].concat(args));
          };
          _iteratee(next);
        }
        function doUntil(iteratee, test, callback) {
          doWhilst(iteratee, function() {
            return !test.apply(this, arguments);
          }, callback);
        }
        function during(test, fn, callback) {
          callback = onlyOnce(callback || noop);
          var _fn = wrapAsync(fn);
          var _test = wrapAsync(test);
          function next(err) {
            if (err) return callback(err);
            _test(check);
          }
          function check(err, truth) {
            if (err) return callback(err);
            if (!truth) return callback(null);
            _fn(next);
          }
          _test(check);
        }
        function _withoutIndex(iteratee) {
          return function(value, index2, callback) {
            return iteratee(value, callback);
          };
        }
        function eachLimit(coll, iteratee, callback) {
          eachOf(coll, _withoutIndex(wrapAsync(iteratee)), callback);
        }
        function eachLimit$1(coll, limit, iteratee, callback) {
          _eachOfLimit(limit)(coll, _withoutIndex(wrapAsync(iteratee)), callback);
        }
        var eachSeries = doLimit(eachLimit$1, 1);
        function ensureAsync(fn) {
          if (isAsync(fn)) return fn;
          return initialParams(function(args, callback) {
            var sync = true;
            args.push(function() {
              var innerArgs = arguments;
              if (sync) {
                setImmediate$1(function() {
                  callback.apply(null, innerArgs);
                });
              } else {
                callback.apply(null, innerArgs);
              }
            });
            fn.apply(this, args);
            sync = false;
          });
        }
        function notId(v) {
          return !v;
        }
        var every = doParallel(_createTester(notId, notId));
        var everyLimit = doParallelLimit(_createTester(notId, notId));
        var everySeries = doLimit(everyLimit, 1);
        function baseProperty(key) {
          return function(object) {
            return object == null ? void 0 : object[key];
          };
        }
        function filterArray(eachfn, arr, iteratee, callback) {
          var truthValues = new Array(arr.length);
          eachfn(arr, function(x, index2, callback2) {
            iteratee(x, function(err, v) {
              truthValues[index2] = !!v;
              callback2(err);
            });
          }, function(err) {
            if (err) return callback(err);
            var results = [];
            for (var i = 0; i < arr.length; i++) {
              if (truthValues[i]) results.push(arr[i]);
            }
            callback(null, results);
          });
        }
        function filterGeneric(eachfn, coll, iteratee, callback) {
          var results = [];
          eachfn(coll, function(x, index2, callback2) {
            iteratee(x, function(err, v) {
              if (err) {
                callback2(err);
              } else {
                if (v) {
                  results.push({ index: index2, value: x });
                }
                callback2();
              }
            });
          }, function(err) {
            if (err) {
              callback(err);
            } else {
              callback(null, arrayMap(results.sort(function(a, b) {
                return a.index - b.index;
              }), baseProperty("value")));
            }
          });
        }
        function _filter(eachfn, coll, iteratee, callback) {
          var filter2 = isArrayLike(coll) ? filterArray : filterGeneric;
          filter2(eachfn, coll, wrapAsync(iteratee), callback || noop);
        }
        var filter = doParallel(_filter);
        var filterLimit = doParallelLimit(_filter);
        var filterSeries = doLimit(filterLimit, 1);
        function forever(fn, errback) {
          var done = onlyOnce(errback || noop);
          var task = wrapAsync(ensureAsync(fn));
          function next(err) {
            if (err) return done(err);
            task(next);
          }
          next();
        }
        var groupByLimit = function(coll, limit, iteratee, callback) {
          callback = callback || noop;
          var _iteratee = wrapAsync(iteratee);
          mapLimit(coll, limit, function(val, callback2) {
            _iteratee(val, function(err, key) {
              if (err) return callback2(err);
              return callback2(null, { key, val });
            });
          }, function(err, mapResults) {
            var result = {};
            var hasOwnProperty2 = Object.prototype.hasOwnProperty;
            for (var i = 0; i < mapResults.length; i++) {
              if (mapResults[i]) {
                var key = mapResults[i].key;
                var val = mapResults[i].val;
                if (hasOwnProperty2.call(result, key)) {
                  result[key].push(val);
                } else {
                  result[key] = [val];
                }
              }
            }
            return callback(err, result);
          });
        };
        var groupBy = doLimit(groupByLimit, Infinity);
        var groupBySeries = doLimit(groupByLimit, 1);
        var log = consoleFunc("log");
        function mapValuesLimit(obj, limit, iteratee, callback) {
          callback = once(callback || noop);
          var newObj = {};
          var _iteratee = wrapAsync(iteratee);
          eachOfLimit(obj, limit, function(val, key, next) {
            _iteratee(val, key, function(err, result) {
              if (err) return next(err);
              newObj[key] = result;
              next();
            });
          }, function(err) {
            callback(err, newObj);
          });
        }
        var mapValues = doLimit(mapValuesLimit, Infinity);
        var mapValuesSeries = doLimit(mapValuesLimit, 1);
        function has(obj, key) {
          return key in obj;
        }
        function memoize(fn, hasher) {
          var memo = /* @__PURE__ */ Object.create(null);
          var queues = /* @__PURE__ */ Object.create(null);
          hasher = hasher || identity;
          var _fn = wrapAsync(fn);
          var memoized = initialParams(function memoized2(args, callback) {
            var key = hasher.apply(null, args);
            if (has(memo, key)) {
              setImmediate$1(function() {
                callback.apply(null, memo[key]);
              });
            } else if (has(queues, key)) {
              queues[key].push(callback);
            } else {
              queues[key] = [callback];
              _fn.apply(null, args.concat(function() {
                var args2 = slice(arguments);
                memo[key] = args2;
                var q = queues[key];
                delete queues[key];
                for (var i = 0, l = q.length; i < l; i++) {
                  q[i].apply(null, args2);
                }
              }));
            }
          });
          memoized.memo = memo;
          memoized.unmemoized = fn;
          return memoized;
        }
        var _defer$1;
        if (hasNextTick) {
          _defer$1 = process.nextTick;
        } else if (hasSetImmediate) {
          _defer$1 = setImmediate;
        } else {
          _defer$1 = fallback;
        }
        var nextTick = wrap(_defer$1);
        function _parallel(eachfn, tasks, callback) {
          callback = callback || noop;
          var results = isArrayLike(tasks) ? [] : {};
          eachfn(tasks, function(task, key, callback2) {
            wrapAsync(task)(function(err, result) {
              if (arguments.length > 2) {
                result = slice(arguments, 1);
              }
              results[key] = result;
              callback2(err);
            });
          }, function(err) {
            callback(err, results);
          });
        }
        function parallelLimit(tasks, callback) {
          _parallel(eachOf, tasks, callback);
        }
        function parallelLimit$1(tasks, limit, callback) {
          _parallel(_eachOfLimit(limit), tasks, callback);
        }
        var queue$1 = function(worker, concurrency) {
          var _worker = wrapAsync(worker);
          return queue(function(items, cb) {
            _worker(items[0], cb);
          }, concurrency, 1);
        };
        var priorityQueue = function(worker, concurrency) {
          var q = queue$1(worker, concurrency);
          q.push = function(data, priority, callback) {
            if (callback == null) callback = noop;
            if (typeof callback !== "function") {
              throw new Error("task callback must be a function");
            }
            q.started = true;
            if (!isArray(data)) {
              data = [data];
            }
            if (data.length === 0) {
              return setImmediate$1(function() {
                q.drain();
              });
            }
            priority = priority || 0;
            var nextNode = q._tasks.head;
            while (nextNode && priority >= nextNode.priority) {
              nextNode = nextNode.next;
            }
            for (var i = 0, l = data.length; i < l; i++) {
              var item = {
                data: data[i],
                priority,
                callback
              };
              if (nextNode) {
                q._tasks.insertBefore(nextNode, item);
              } else {
                q._tasks.push(item);
              }
            }
            setImmediate$1(q.process);
          };
          delete q.unshift;
          return q;
        };
        function race(tasks, callback) {
          callback = once(callback || noop);
          if (!isArray(tasks)) return callback(new TypeError("First argument to race must be an array of functions"));
          if (!tasks.length) return callback();
          for (var i = 0, l = tasks.length; i < l; i++) {
            wrapAsync(tasks[i])(callback);
          }
        }
        function reduceRight(array, memo, iteratee, callback) {
          var reversed = slice(array).reverse();
          reduce(reversed, memo, iteratee, callback);
        }
        function reflect(fn) {
          var _fn = wrapAsync(fn);
          return initialParams(function reflectOn(args, reflectCallback) {
            args.push(function callback(error, cbArg) {
              if (error) {
                reflectCallback(null, { error });
              } else {
                var value;
                if (arguments.length <= 2) {
                  value = cbArg;
                } else {
                  value = slice(arguments, 1);
                }
                reflectCallback(null, { value });
              }
            });
            return _fn.apply(this, args);
          });
        }
        function reflectAll(tasks) {
          var results;
          if (isArray(tasks)) {
            results = arrayMap(tasks, reflect);
          } else {
            results = {};
            baseForOwn(tasks, function(task, key) {
              results[key] = reflect.call(this, task);
            });
          }
          return results;
        }
        function reject$1(eachfn, arr, iteratee, callback) {
          _filter(eachfn, arr, function(value, cb) {
            iteratee(value, function(err, v) {
              cb(err, !v);
            });
          }, callback);
        }
        var reject = doParallel(reject$1);
        var rejectLimit = doParallelLimit(reject$1);
        var rejectSeries = doLimit(rejectLimit, 1);
        function constant$1(value) {
          return function() {
            return value;
          };
        }
        function retry(opts, task, callback) {
          var DEFAULT_TIMES = 5;
          var DEFAULT_INTERVAL = 0;
          var options = {
            times: DEFAULT_TIMES,
            intervalFunc: constant$1(DEFAULT_INTERVAL)
          };
          function parseTimes(acc, t) {
            if (typeof t === "object") {
              acc.times = +t.times || DEFAULT_TIMES;
              acc.intervalFunc = typeof t.interval === "function" ? t.interval : constant$1(+t.interval || DEFAULT_INTERVAL);
              acc.errorFilter = t.errorFilter;
            } else if (typeof t === "number" || typeof t === "string") {
              acc.times = +t || DEFAULT_TIMES;
            } else {
              throw new Error("Invalid arguments for async.retry");
            }
          }
          if (arguments.length < 3 && typeof opts === "function") {
            callback = task || noop;
            task = opts;
          } else {
            parseTimes(options, opts);
            callback = callback || noop;
          }
          if (typeof task !== "function") {
            throw new Error("Invalid arguments for async.retry");
          }
          var _task = wrapAsync(task);
          var attempt = 1;
          function retryAttempt() {
            _task(function(err) {
              if (err && attempt++ < options.times && (typeof options.errorFilter != "function" || options.errorFilter(err))) {
                setTimeout(retryAttempt, options.intervalFunc(attempt));
              } else {
                callback.apply(null, arguments);
              }
            });
          }
          retryAttempt();
        }
        var retryable = function(opts, task) {
          if (!task) {
            task = opts;
            opts = null;
          }
          var _task = wrapAsync(task);
          return initialParams(function(args, callback) {
            function taskFn(cb) {
              _task.apply(null, args.concat(cb));
            }
            if (opts) retry(opts, taskFn, callback);
            else retry(taskFn, callback);
          });
        };
        function series(tasks, callback) {
          _parallel(eachOfSeries, tasks, callback);
        }
        var some = doParallel(_createTester(Boolean, identity));
        var someLimit = doParallelLimit(_createTester(Boolean, identity));
        var someSeries = doLimit(someLimit, 1);
        function sortBy(coll, iteratee, callback) {
          var _iteratee = wrapAsync(iteratee);
          map(coll, function(x, callback2) {
            _iteratee(x, function(err, criteria) {
              if (err) return callback2(err);
              callback2(null, { value: x, criteria });
            });
          }, function(err, results) {
            if (err) return callback(err);
            callback(null, arrayMap(results.sort(comparator), baseProperty("value")));
          });
          function comparator(left, right) {
            var a = left.criteria, b = right.criteria;
            return a < b ? -1 : a > b ? 1 : 0;
          }
        }
        function timeout(asyncFn, milliseconds, info) {
          var fn = wrapAsync(asyncFn);
          return initialParams(function(args, callback) {
            var timedOut = false;
            var timer;
            function timeoutCallback() {
              var name = asyncFn.name || "anonymous";
              var error = new Error('Callback function "' + name + '" timed out.');
              error.code = "ETIMEDOUT";
              if (info) {
                error.info = info;
              }
              timedOut = true;
              callback(error);
            }
            args.push(function() {
              if (!timedOut) {
                callback.apply(null, arguments);
                clearTimeout(timer);
              }
            });
            timer = setTimeout(timeoutCallback, milliseconds);
            fn.apply(null, args);
          });
        }
        var nativeCeil = Math.ceil;
        var nativeMax = Math.max;
        function baseRange(start, end, step, fromRight) {
          var index2 = -1, length = nativeMax(nativeCeil((end - start) / step), 0), result = Array(length);
          while (length--) {
            result[++index2] = start;
            start += step;
          }
          return result;
        }
        function timeLimit(count, limit, iteratee, callback) {
          var _iteratee = wrapAsync(iteratee);
          mapLimit(baseRange(0, count, 1), limit, _iteratee, callback);
        }
        var times = doLimit(timeLimit, Infinity);
        var timesSeries = doLimit(timeLimit, 1);
        function transform(coll, accumulator, iteratee, callback) {
          if (arguments.length <= 3) {
            callback = iteratee;
            iteratee = accumulator;
            accumulator = isArray(coll) ? [] : {};
          }
          callback = once(callback || noop);
          var _iteratee = wrapAsync(iteratee);
          eachOf(coll, function(v, k, cb) {
            _iteratee(accumulator, v, k, cb);
          }, function(err) {
            callback(err, accumulator);
          });
        }
        function tryEach(tasks, callback) {
          var error = null;
          var result;
          callback = callback || noop;
          eachSeries(tasks, function(task, callback2) {
            wrapAsync(task)(function(err, res) {
              if (arguments.length > 2) {
                result = slice(arguments, 1);
              } else {
                result = res;
              }
              error = err;
              callback2(!err);
            });
          }, function() {
            callback(error, result);
          });
        }
        function unmemoize(fn) {
          return function() {
            return (fn.unmemoized || fn).apply(null, arguments);
          };
        }
        function whilst(test, iteratee, callback) {
          callback = onlyOnce(callback || noop);
          var _iteratee = wrapAsync(iteratee);
          if (!test()) return callback(null);
          var next = function(err) {
            if (err) return callback(err);
            if (test()) return _iteratee(next);
            var args = slice(arguments, 1);
            callback.apply(null, [null].concat(args));
          };
          _iteratee(next);
        }
        function until(test, iteratee, callback) {
          whilst(function() {
            return !test.apply(this, arguments);
          }, iteratee, callback);
        }
        var waterfall = function(tasks, callback) {
          callback = once(callback || noop);
          if (!isArray(tasks)) return callback(new Error("First argument to waterfall must be an array of functions"));
          if (!tasks.length) return callback();
          var taskIndex = 0;
          function nextTask(args) {
            var task = wrapAsync(tasks[taskIndex++]);
            args.push(onlyOnce(next));
            task.apply(null, args);
          }
          function next(err) {
            if (err || taskIndex === tasks.length) {
              return callback.apply(null, arguments);
            }
            nextTask(slice(arguments, 1));
          }
          nextTask([]);
        };
        var index = {
          apply,
          applyEach,
          applyEachSeries,
          asyncify,
          auto,
          autoInject,
          cargo,
          compose,
          concat,
          concatLimit,
          concatSeries,
          constant,
          detect,
          detectLimit,
          detectSeries,
          dir,
          doDuring,
          doUntil,
          doWhilst,
          during,
          each: eachLimit,
          eachLimit: eachLimit$1,
          eachOf,
          eachOfLimit,
          eachOfSeries,
          eachSeries,
          ensureAsync,
          every,
          everyLimit,
          everySeries,
          filter,
          filterLimit,
          filterSeries,
          forever,
          groupBy,
          groupByLimit,
          groupBySeries,
          log,
          map,
          mapLimit,
          mapSeries,
          mapValues,
          mapValuesLimit,
          mapValuesSeries,
          memoize,
          nextTick,
          parallel: parallelLimit,
          parallelLimit: parallelLimit$1,
          priorityQueue,
          queue: queue$1,
          race,
          reduce,
          reduceRight,
          reflect,
          reflectAll,
          reject,
          rejectLimit,
          rejectSeries,
          retry,
          retryable,
          seq,
          series,
          setImmediate: setImmediate$1,
          some,
          someLimit,
          someSeries,
          sortBy,
          timeout,
          times,
          timesLimit: timeLimit,
          timesSeries,
          transform,
          tryEach,
          unmemoize,
          until,
          waterfall,
          whilst,
          // aliases
          all: every,
          allLimit: everyLimit,
          allSeries: everySeries,
          any: some,
          anyLimit: someLimit,
          anySeries: someSeries,
          find: detect,
          findLimit: detectLimit,
          findSeries: detectSeries,
          forEach: eachLimit,
          forEachSeries: eachSeries,
          forEachLimit: eachLimit$1,
          forEachOf: eachOf,
          forEachOfSeries: eachOfSeries,
          forEachOfLimit: eachOfLimit,
          inject: reduce,
          foldl: reduce,
          foldr: reduceRight,
          select: filter,
          selectLimit: filterLimit,
          selectSeries: filterSeries,
          wrapSync: asyncify
        };
        exports$12["default"] = index;
        exports$12.apply = apply;
        exports$12.applyEach = applyEach;
        exports$12.applyEachSeries = applyEachSeries;
        exports$12.asyncify = asyncify;
        exports$12.auto = auto;
        exports$12.autoInject = autoInject;
        exports$12.cargo = cargo;
        exports$12.compose = compose;
        exports$12.concat = concat;
        exports$12.concatLimit = concatLimit;
        exports$12.concatSeries = concatSeries;
        exports$12.constant = constant;
        exports$12.detect = detect;
        exports$12.detectLimit = detectLimit;
        exports$12.detectSeries = detectSeries;
        exports$12.dir = dir;
        exports$12.doDuring = doDuring;
        exports$12.doUntil = doUntil;
        exports$12.doWhilst = doWhilst;
        exports$12.during = during;
        exports$12.each = eachLimit;
        exports$12.eachLimit = eachLimit$1;
        exports$12.eachOf = eachOf;
        exports$12.eachOfLimit = eachOfLimit;
        exports$12.eachOfSeries = eachOfSeries;
        exports$12.eachSeries = eachSeries;
        exports$12.ensureAsync = ensureAsync;
        exports$12.every = every;
        exports$12.everyLimit = everyLimit;
        exports$12.everySeries = everySeries;
        exports$12.filter = filter;
        exports$12.filterLimit = filterLimit;
        exports$12.filterSeries = filterSeries;
        exports$12.forever = forever;
        exports$12.groupBy = groupBy;
        exports$12.groupByLimit = groupByLimit;
        exports$12.groupBySeries = groupBySeries;
        exports$12.log = log;
        exports$12.map = map;
        exports$12.mapLimit = mapLimit;
        exports$12.mapSeries = mapSeries;
        exports$12.mapValues = mapValues;
        exports$12.mapValuesLimit = mapValuesLimit;
        exports$12.mapValuesSeries = mapValuesSeries;
        exports$12.memoize = memoize;
        exports$12.nextTick = nextTick;
        exports$12.parallel = parallelLimit;
        exports$12.parallelLimit = parallelLimit$1;
        exports$12.priorityQueue = priorityQueue;
        exports$12.queue = queue$1;
        exports$12.race = race;
        exports$12.reduce = reduce;
        exports$12.reduceRight = reduceRight;
        exports$12.reflect = reflect;
        exports$12.reflectAll = reflectAll;
        exports$12.reject = reject;
        exports$12.rejectLimit = rejectLimit;
        exports$12.rejectSeries = rejectSeries;
        exports$12.retry = retry;
        exports$12.retryable = retryable;
        exports$12.seq = seq;
        exports$12.series = series;
        exports$12.setImmediate = setImmediate$1;
        exports$12.some = some;
        exports$12.someLimit = someLimit;
        exports$12.someSeries = someSeries;
        exports$12.sortBy = sortBy;
        exports$12.timeout = timeout;
        exports$12.times = times;
        exports$12.timesLimit = timeLimit;
        exports$12.timesSeries = timesSeries;
        exports$12.transform = transform;
        exports$12.tryEach = tryEach;
        exports$12.unmemoize = unmemoize;
        exports$12.until = until;
        exports$12.waterfall = waterfall;
        exports$12.whilst = whilst;
        exports$12.all = every;
        exports$12.allLimit = everyLimit;
        exports$12.allSeries = everySeries;
        exports$12.any = some;
        exports$12.anyLimit = someLimit;
        exports$12.anySeries = someSeries;
        exports$12.find = detect;
        exports$12.findLimit = detectLimit;
        exports$12.findSeries = detectSeries;
        exports$12.forEach = eachLimit;
        exports$12.forEachSeries = eachSeries;
        exports$12.forEachLimit = eachLimit$1;
        exports$12.forEachOf = eachOf;
        exports$12.forEachOfSeries = eachOfSeries;
        exports$12.forEachOfLimit = eachOfLimit;
        exports$12.inject = reduce;
        exports$12.foldl = reduce;
        exports$12.foldr = reduceRight;
        exports$12.select = filter;
        exports$12.selectLimit = filterLimit;
        exports$12.selectSeries = filterSeries;
        exports$12.wrapSync = asyncify;
        Object.defineProperty(exports$12, "__esModule", { value: true });
      }));
    })(async$1, async$1.exports);
    return async$1.exports;
  }
  var doublearray = { exports: {} };
  var hasRequiredDoublearray;
  function requireDoublearray() {
    if (hasRequiredDoublearray) return doublearray.exports;
    hasRequiredDoublearray = 1;
    (function(module2) {
      (function() {
        var TERM_CHAR = "\0", TERM_CODE = 0, ROOT_ID = 0, NOT_FOUND = -1, BASE_SIGNED = true, CHECK_SIGNED = true, BASE_BYTES = 4, CHECK_BYTES = 4, MEMORY_EXPAND_RATIO = 2;
        var newBC = function(initial_size) {
          if (initial_size == null) {
            initial_size = 1024;
          }
          var initBase = function(_base, start, end) {
            for (var i = start; i < end; i++) {
              _base[i] = -i + 1;
            }
            if (0 < check.array[check.array.length - 1]) {
              var last_used_id = check.array.length - 2;
              while (0 < check.array[last_used_id]) {
                last_used_id--;
              }
              _base[start] = -last_used_id;
            }
          };
          var initCheck = function(_check, start, end) {
            for (var i = start; i < end; i++) {
              _check[i] = -i - 1;
            }
          };
          var realloc = function(min_size) {
            var new_size = min_size * MEMORY_EXPAND_RATIO;
            var base_new_array = newArrayBuffer(base.signed, base.bytes, new_size);
            initBase(base_new_array, base.array.length, new_size);
            base_new_array.set(base.array);
            base.array = null;
            base.array = base_new_array;
            var check_new_array = newArrayBuffer(check.signed, check.bytes, new_size);
            initCheck(check_new_array, check.array.length, new_size);
            check_new_array.set(check.array);
            check.array = null;
            check.array = check_new_array;
          };
          var first_unused_node = ROOT_ID + 1;
          var base = {
            signed: BASE_SIGNED,
            bytes: BASE_BYTES,
            array: newArrayBuffer(BASE_SIGNED, BASE_BYTES, initial_size)
          };
          var check = {
            signed: CHECK_SIGNED,
            bytes: CHECK_BYTES,
            array: newArrayBuffer(CHECK_SIGNED, CHECK_BYTES, initial_size)
          };
          base.array[ROOT_ID] = 1;
          check.array[ROOT_ID] = ROOT_ID;
          initBase(base.array, ROOT_ID + 1, base.array.length);
          initCheck(check.array, ROOT_ID + 1, check.array.length);
          return {
            getBaseBuffer: function() {
              return base.array;
            },
            getCheckBuffer: function() {
              return check.array;
            },
            loadBaseBuffer: function(base_buffer) {
              base.array = base_buffer;
              return this;
            },
            loadCheckBuffer: function(check_buffer) {
              check.array = check_buffer;
              return this;
            },
            size: function() {
              return Math.max(base.array.length, check.array.length);
            },
            getBase: function(index) {
              if (base.array.length - 1 < index) {
                return -index + 1;
              }
              return base.array[index];
            },
            getCheck: function(index) {
              if (check.array.length - 1 < index) {
                return -index - 1;
              }
              return check.array[index];
            },
            setBase: function(index, base_value) {
              if (base.array.length - 1 < index) {
                realloc(index);
              }
              base.array[index] = base_value;
            },
            setCheck: function(index, check_value) {
              if (check.array.length - 1 < index) {
                realloc(index);
              }
              check.array[index] = check_value;
            },
            setFirstUnusedNode: function(index) {
              first_unused_node = index;
            },
            getFirstUnusedNode: function() {
              return first_unused_node;
            },
            shrink: function() {
              var last_index = this.size() - 1;
              while (true) {
                if (0 <= check.array[last_index]) {
                  break;
                }
                last_index--;
              }
              base.array = base.array.subarray(0, last_index + 2);
              check.array = check.array.subarray(0, last_index + 2);
            },
            calc: function() {
              var unused_count = 0;
              var size = check.array.length;
              for (var i = 0; i < size; i++) {
                if (check.array[i] < 0) {
                  unused_count++;
                }
              }
              return {
                all: size,
                unused: unused_count,
                efficiency: (size - unused_count) / size
              };
            },
            dump: function() {
              var dump_base = "";
              var dump_check = "";
              var i;
              for (i = 0; i < base.array.length; i++) {
                dump_base = dump_base + " " + this.getBase(i);
              }
              for (i = 0; i < check.array.length; i++) {
                dump_check = dump_check + " " + this.getCheck(i);
              }
              console.log("base:" + dump_base);
              console.log("chck:" + dump_check);
              return "base:" + dump_base + " chck:" + dump_check;
            }
          };
        };
        function DoubleArrayBuilder(initial_size) {
          this.bc = newBC(initial_size);
          this.keys = [];
        }
        DoubleArrayBuilder.prototype.append = function(key, record) {
          this.keys.push({ k: key, v: record });
          return this;
        };
        DoubleArrayBuilder.prototype.build = function(keys, sorted) {
          if (keys == null) {
            keys = this.keys;
          }
          if (keys == null) {
            return new DoubleArray(this.bc);
          }
          if (sorted == null) {
            sorted = false;
          }
          var buff_keys = keys.map(function(k) {
            return {
              k: stringToUtf8Bytes(k.k + TERM_CHAR),
              v: k.v
            };
          });
          if (sorted) {
            this.keys = buff_keys;
          } else {
            this.keys = buff_keys.sort(function(k1, k2) {
              var b1 = k1.k;
              var b2 = k2.k;
              var min_length = Math.min(b1.length, b2.length);
              for (var pos = 0; pos < min_length; pos++) {
                if (b1[pos] === b2[pos]) {
                  continue;
                }
                return b1[pos] - b2[pos];
              }
              return b1.length - b2.length;
            });
          }
          buff_keys = null;
          this._build(ROOT_ID, 0, 0, this.keys.length);
          return new DoubleArray(this.bc);
        };
        DoubleArrayBuilder.prototype._build = function(parent_index, position, start, length) {
          var children_info = this.getChildrenInfo(position, start, length);
          var _base = this.findAllocatableBase(children_info);
          this.setBC(parent_index, children_info, _base);
          for (var i = 0; i < children_info.length; i = i + 3) {
            var child_code = children_info[i];
            if (child_code === TERM_CODE) {
              continue;
            }
            var child_start = children_info[i + 1];
            var child_len = children_info[i + 2];
            var child_index = _base + child_code;
            this._build(child_index, position + 1, child_start, child_len);
          }
        };
        DoubleArrayBuilder.prototype.getChildrenInfo = function(position, start, length) {
          var current_char = this.keys[start].k[position];
          var i = 0;
          var children_info = new Int32Array(length * 3);
          children_info[i++] = current_char;
          children_info[i++] = start;
          var next_pos = start;
          var start_pos = start;
          for (; next_pos < start + length; next_pos++) {
            var next_char = this.keys[next_pos].k[position];
            if (current_char !== next_char) {
              children_info[i++] = next_pos - start_pos;
              children_info[i++] = next_char;
              children_info[i++] = next_pos;
              current_char = next_char;
              start_pos = next_pos;
            }
          }
          children_info[i++] = next_pos - start_pos;
          children_info = children_info.subarray(0, i);
          return children_info;
        };
        DoubleArrayBuilder.prototype.setBC = function(parent_id, children_info, _base) {
          var bc = this.bc;
          bc.setBase(parent_id, _base);
          var i;
          for (i = 0; i < children_info.length; i = i + 3) {
            var code = children_info[i];
            var child_id = _base + code;
            var prev_unused_id = -bc.getBase(child_id);
            var next_unused_id = -bc.getCheck(child_id);
            if (child_id !== bc.getFirstUnusedNode()) {
              bc.setCheck(prev_unused_id, -next_unused_id);
            } else {
              bc.setFirstUnusedNode(next_unused_id);
            }
            bc.setBase(next_unused_id, -prev_unused_id);
            var check = parent_id;
            bc.setCheck(child_id, check);
            if (code === TERM_CODE) {
              var start_pos = children_info[i + 1];
              var value = this.keys[start_pos].v;
              if (value == null) {
                value = 0;
              }
              var base = -value - 1;
              bc.setBase(child_id, base);
            }
          }
        };
        DoubleArrayBuilder.prototype.findAllocatableBase = function(children_info) {
          var bc = this.bc;
          var _base;
          var curr = bc.getFirstUnusedNode();
          while (true) {
            _base = curr - children_info[0];
            if (_base < 0) {
              curr = -bc.getCheck(curr);
              continue;
            }
            var empty_area_found = true;
            for (var i = 0; i < children_info.length; i = i + 3) {
              var code = children_info[i];
              var candidate_id = _base + code;
              if (!this.isUnusedNode(candidate_id)) {
                curr = -bc.getCheck(curr);
                empty_area_found = false;
                break;
              }
            }
            if (empty_area_found) {
              return _base;
            }
          }
        };
        DoubleArrayBuilder.prototype.isUnusedNode = function(index) {
          var bc = this.bc;
          var check = bc.getCheck(index);
          if (index === ROOT_ID) {
            return false;
          }
          if (check < 0) {
            return true;
          }
          return false;
        };
        function DoubleArray(bc) {
          this.bc = bc;
          this.bc.shrink();
        }
        DoubleArray.prototype.contain = function(key) {
          var bc = this.bc;
          key += TERM_CHAR;
          var buffer = stringToUtf8Bytes(key);
          var parent = ROOT_ID;
          var child = NOT_FOUND;
          for (var i = 0; i < buffer.length; i++) {
            var code = buffer[i];
            child = this.traverse(parent, code);
            if (child === NOT_FOUND) {
              return false;
            }
            if (bc.getBase(child) <= 0) {
              return true;
            } else {
              parent = child;
              continue;
            }
          }
          return false;
        };
        DoubleArray.prototype.lookup = function(key) {
          key += TERM_CHAR;
          var buffer = stringToUtf8Bytes(key);
          var parent = ROOT_ID;
          var child = NOT_FOUND;
          for (var i = 0; i < buffer.length; i++) {
            var code = buffer[i];
            child = this.traverse(parent, code);
            if (child === NOT_FOUND) {
              return NOT_FOUND;
            }
            parent = child;
          }
          var base = this.bc.getBase(child);
          if (base <= 0) {
            return -base - 1;
          } else {
            return NOT_FOUND;
          }
        };
        DoubleArray.prototype.commonPrefixSearch = function(key) {
          var buffer = stringToUtf8Bytes(key);
          var parent = ROOT_ID;
          var child = NOT_FOUND;
          var result = [];
          for (var i = 0; i < buffer.length; i++) {
            var code = buffer[i];
            child = this.traverse(parent, code);
            if (child !== NOT_FOUND) {
              parent = child;
              var grand_child = this.traverse(child, TERM_CODE);
              if (grand_child !== NOT_FOUND) {
                var base = this.bc.getBase(grand_child);
                var r = {};
                if (base <= 0) {
                  r.v = -base - 1;
                }
                r.k = utf8BytesToString(arrayCopy(buffer, 0, i + 1));
                result.push(r);
              }
              continue;
            } else {
              break;
            }
          }
          return result;
        };
        DoubleArray.prototype.traverse = function(parent, code) {
          var child = this.bc.getBase(parent) + code;
          if (this.bc.getCheck(child) === parent) {
            return child;
          } else {
            return NOT_FOUND;
          }
        };
        DoubleArray.prototype.size = function() {
          return this.bc.size();
        };
        DoubleArray.prototype.calc = function() {
          return this.bc.calc();
        };
        DoubleArray.prototype.dump = function() {
          return this.bc.dump();
        };
        var newArrayBuffer = function(signed, bytes, size) {
          {
            switch (bytes) {
              case 1:
                return new Int8Array(size);
              case 2:
                return new Int16Array(size);
              case 4:
                return new Int32Array(size);
              default:
                throw new RangeError("Invalid newArray parameter element_bytes:" + bytes);
            }
          }
        };
        var arrayCopy = function(src, src_offset, length) {
          var buffer = new ArrayBuffer(length);
          var dstU8 = new Uint8Array(buffer, 0, length);
          var srcU8 = src.subarray(src_offset, length);
          dstU8.set(srcU8);
          return dstU8;
        };
        var stringToUtf8Bytes = function(str) {
          var bytes = new Uint8Array(new ArrayBuffer(str.length * 4));
          var i = 0, j = 0;
          while (i < str.length) {
            var unicode_code;
            var utf16_code = str.charCodeAt(i++);
            if (utf16_code >= 55296 && utf16_code <= 56319) {
              var upper = utf16_code;
              var lower = str.charCodeAt(i++);
              if (lower >= 56320 && lower <= 57343) {
                unicode_code = (upper - 55296) * (1 << 10) + (1 << 16) + (lower - 56320);
              } else {
                return null;
              }
            } else {
              unicode_code = utf16_code;
            }
            if (unicode_code < 128) {
              bytes[j++] = unicode_code;
            } else if (unicode_code < 1 << 11) {
              bytes[j++] = unicode_code >>> 6 | 192;
              bytes[j++] = unicode_code & 63 | 128;
            } else if (unicode_code < 1 << 16) {
              bytes[j++] = unicode_code >>> 12 | 224;
              bytes[j++] = unicode_code >> 6 & 63 | 128;
              bytes[j++] = unicode_code & 63 | 128;
            } else if (unicode_code < 1 << 21) {
              bytes[j++] = unicode_code >>> 18 | 240;
              bytes[j++] = unicode_code >> 12 & 63 | 128;
              bytes[j++] = unicode_code >> 6 & 63 | 128;
              bytes[j++] = unicode_code & 63 | 128;
            } else ;
          }
          return bytes.subarray(0, j);
        };
        var utf8BytesToString = function(bytes) {
          var str = "";
          var code, b1, b2, b3, b4, upper, lower;
          var i = 0;
          while (i < bytes.length) {
            b1 = bytes[i++];
            if (b1 < 128) {
              code = b1;
            } else if (b1 >> 5 === 6) {
              b2 = bytes[i++];
              code = (b1 & 31) << 6 | b2 & 63;
            } else if (b1 >> 4 === 14) {
              b2 = bytes[i++];
              b3 = bytes[i++];
              code = (b1 & 15) << 12 | (b2 & 63) << 6 | b3 & 63;
            } else {
              b2 = bytes[i++];
              b3 = bytes[i++];
              b4 = bytes[i++];
              code = (b1 & 7) << 18 | (b2 & 63) << 12 | (b3 & 63) << 6 | b4 & 63;
            }
            if (code < 65536) {
              str += String.fromCharCode(code);
            } else {
              code -= 65536;
              upper = 55296 | code >> 10;
              lower = 56320 | code & 1023;
              str += String.fromCharCode(upper, lower);
            }
          }
          return str;
        };
        var doublearray2 = {
          builder: function(initial_size) {
            return new DoubleArrayBuilder(initial_size);
          },
          load: function(base_buffer, check_buffer) {
            var bc = newBC(0);
            bc.loadBaseBuffer(base_buffer);
            bc.loadCheckBuffer(check_buffer);
            return new DoubleArray(bc);
          }
        };
        {
          module2.exports = doublearray2;
        }
      })();
    })(doublearray);
    return doublearray.exports;
  }
  var ByteBuffer_1;
  var hasRequiredByteBuffer;
  function requireByteBuffer() {
    if (hasRequiredByteBuffer) return ByteBuffer_1;
    hasRequiredByteBuffer = 1;
    var stringToUtf8Bytes = function(str) {
      var bytes = new Uint8Array(str.length * 4);
      var i = 0, j = 0;
      while (i < str.length) {
        var unicode_code;
        var utf16_code = str.charCodeAt(i++);
        if (utf16_code >= 55296 && utf16_code <= 56319) {
          var upper = utf16_code;
          var lower = str.charCodeAt(i++);
          if (lower >= 56320 && lower <= 57343) {
            unicode_code = (upper - 55296) * (1 << 10) + (1 << 16) + (lower - 56320);
          } else {
            return null;
          }
        } else {
          unicode_code = utf16_code;
        }
        if (unicode_code < 128) {
          bytes[j++] = unicode_code;
        } else if (unicode_code < 1 << 11) {
          bytes[j++] = unicode_code >>> 6 | 192;
          bytes[j++] = unicode_code & 63 | 128;
        } else if (unicode_code < 1 << 16) {
          bytes[j++] = unicode_code >>> 12 | 224;
          bytes[j++] = unicode_code >> 6 & 63 | 128;
          bytes[j++] = unicode_code & 63 | 128;
        } else if (unicode_code < 1 << 21) {
          bytes[j++] = unicode_code >>> 18 | 240;
          bytes[j++] = unicode_code >> 12 & 63 | 128;
          bytes[j++] = unicode_code >> 6 & 63 | 128;
          bytes[j++] = unicode_code & 63 | 128;
        } else ;
      }
      return bytes.subarray(0, j);
    };
    var utf8BytesToString = function(bytes) {
      var str = "";
      var code, b1, b2, b3, b4, upper, lower;
      var i = 0;
      while (i < bytes.length) {
        b1 = bytes[i++];
        if (b1 < 128) {
          code = b1;
        } else if (b1 >> 5 === 6) {
          b2 = bytes[i++];
          code = (b1 & 31) << 6 | b2 & 63;
        } else if (b1 >> 4 === 14) {
          b2 = bytes[i++];
          b3 = bytes[i++];
          code = (b1 & 15) << 12 | (b2 & 63) << 6 | b3 & 63;
        } else {
          b2 = bytes[i++];
          b3 = bytes[i++];
          b4 = bytes[i++];
          code = (b1 & 7) << 18 | (b2 & 63) << 12 | (b3 & 63) << 6 | b4 & 63;
        }
        if (code < 65536) {
          str += String.fromCharCode(code);
        } else {
          code -= 65536;
          upper = 55296 | code >> 10;
          lower = 56320 | code & 1023;
          str += String.fromCharCode(upper, lower);
        }
      }
      return str;
    };
    function ByteBuffer(arg) {
      var initial_size;
      if (arg == null) {
        initial_size = 1024 * 1024;
      } else if (typeof arg === "number") {
        initial_size = arg;
      } else if (arg instanceof Uint8Array) {
        this.buffer = arg;
        this.position = 0;
        return;
      } else {
        throw typeof arg + " is invalid parameter type for ByteBuffer constructor";
      }
      this.buffer = new Uint8Array(initial_size);
      this.position = 0;
    }
    ByteBuffer.prototype.size = function() {
      return this.buffer.length;
    };
    ByteBuffer.prototype.reallocate = function() {
      var new_array = new Uint8Array(this.buffer.length * 2);
      new_array.set(this.buffer);
      this.buffer = new_array;
    };
    ByteBuffer.prototype.shrink = function() {
      this.buffer = this.buffer.subarray(0, this.position);
      return this.buffer;
    };
    ByteBuffer.prototype.put = function(b) {
      if (this.buffer.length < this.position + 1) {
        this.reallocate();
      }
      this.buffer[this.position++] = b;
    };
    ByteBuffer.prototype.get = function(index) {
      if (index == null) {
        index = this.position;
        this.position += 1;
      }
      if (this.buffer.length < index + 1) {
        return 0;
      }
      return this.buffer[index];
    };
    ByteBuffer.prototype.putShort = function(num) {
      if (65535 < num) {
        throw num + " is over short value";
      }
      var lower = 255 & num;
      var upper = (65280 & num) >> 8;
      this.put(lower);
      this.put(upper);
    };
    ByteBuffer.prototype.getShort = function(index) {
      if (index == null) {
        index = this.position;
        this.position += 2;
      }
      if (this.buffer.length < index + 2) {
        return 0;
      }
      var lower = this.buffer[index];
      var upper = this.buffer[index + 1];
      var value = (upper << 8) + lower;
      if (value & 32768) {
        value = -(value - 1 ^ 65535);
      }
      return value;
    };
    ByteBuffer.prototype.putInt = function(num) {
      if (4294967295 < num) {
        throw num + " is over integer value";
      }
      var b0 = 255 & num;
      var b1 = (65280 & num) >> 8;
      var b2 = (16711680 & num) >> 16;
      var b3 = (4278190080 & num) >> 24;
      this.put(b0);
      this.put(b1);
      this.put(b2);
      this.put(b3);
    };
    ByteBuffer.prototype.getInt = function(index) {
      if (index == null) {
        index = this.position;
        this.position += 4;
      }
      if (this.buffer.length < index + 4) {
        return 0;
      }
      var b0 = this.buffer[index];
      var b1 = this.buffer[index + 1];
      var b2 = this.buffer[index + 2];
      var b3 = this.buffer[index + 3];
      return (b3 << 24) + (b2 << 16) + (b1 << 8) + b0;
    };
    ByteBuffer.prototype.readInt = function() {
      var pos = this.position;
      this.position += 4;
      return this.getInt(pos);
    };
    ByteBuffer.prototype.putString = function(str) {
      var bytes = stringToUtf8Bytes(str);
      for (var i = 0; i < bytes.length; i++) {
        this.put(bytes[i]);
      }
      this.put(0);
    };
    ByteBuffer.prototype.getString = function(index) {
      var buf = [], ch;
      if (index == null) {
        index = this.position;
      }
      while (true) {
        if (this.buffer.length < index + 1) {
          break;
        }
        ch = this.get(index++);
        if (ch === 0) {
          break;
        } else {
          buf.push(ch);
        }
      }
      this.position = index;
      return utf8BytesToString(buf);
    };
    ByteBuffer_1 = ByteBuffer;
    return ByteBuffer_1;
  }
  var TokenInfoDictionary_1;
  var hasRequiredTokenInfoDictionary;
  function requireTokenInfoDictionary() {
    if (hasRequiredTokenInfoDictionary) return TokenInfoDictionary_1;
    hasRequiredTokenInfoDictionary = 1;
    var ByteBuffer = requireByteBuffer();
    function TokenInfoDictionary() {
      this.dictionary = new ByteBuffer(10 * 1024 * 1024);
      this.target_map = {};
      this.pos_buffer = new ByteBuffer(10 * 1024 * 1024);
    }
    TokenInfoDictionary.prototype.buildDictionary = function(entries) {
      var dictionary_entries = {};
      for (var i = 0; i < entries.length; i++) {
        var entry = entries[i];
        if (entry.length < 4) {
          continue;
        }
        var surface_form = entry[0];
        var left_id = entry[1];
        var right_id = entry[2];
        var word_cost = entry[3];
        var feature = entry.slice(4).join(",");
        if (!isFinite(left_id) || !isFinite(right_id) || !isFinite(word_cost)) {
          console.log(entry);
        }
        var token_info_id = this.put(left_id, right_id, word_cost, surface_form, feature);
        dictionary_entries[token_info_id] = surface_form;
      }
      this.dictionary.shrink();
      this.pos_buffer.shrink();
      return dictionary_entries;
    };
    TokenInfoDictionary.prototype.put = function(left_id, right_id, word_cost, surface_form, feature) {
      var token_info_id = this.dictionary.position;
      var pos_id = this.pos_buffer.position;
      this.dictionary.putShort(left_id);
      this.dictionary.putShort(right_id);
      this.dictionary.putShort(word_cost);
      this.dictionary.putInt(pos_id);
      this.pos_buffer.putString(surface_form + "," + feature);
      return token_info_id;
    };
    TokenInfoDictionary.prototype.addMapping = function(source, target) {
      var mapping = this.target_map[source];
      if (mapping == null) {
        mapping = [];
      }
      mapping.push(target);
      this.target_map[source] = mapping;
    };
    TokenInfoDictionary.prototype.targetMapToBuffer = function() {
      var buffer = new ByteBuffer();
      var map_keys_size = Object.keys(this.target_map).length;
      buffer.putInt(map_keys_size);
      for (var key in this.target_map) {
        var values = this.target_map[key];
        var map_values_size = values.length;
        buffer.putInt(parseInt(key));
        buffer.putInt(map_values_size);
        for (var i = 0; i < values.length; i++) {
          buffer.putInt(values[i]);
        }
      }
      return buffer.shrink();
    };
    TokenInfoDictionary.prototype.loadDictionary = function(array_buffer) {
      this.dictionary = new ByteBuffer(array_buffer);
      return this;
    };
    TokenInfoDictionary.prototype.loadPosVector = function(array_buffer) {
      this.pos_buffer = new ByteBuffer(array_buffer);
      return this;
    };
    TokenInfoDictionary.prototype.loadTargetMap = function(array_buffer) {
      var buffer = new ByteBuffer(array_buffer);
      buffer.position = 0;
      this.target_map = {};
      buffer.readInt();
      while (true) {
        if (buffer.buffer.length < buffer.position + 1) {
          break;
        }
        var key = buffer.readInt();
        var map_values_size = buffer.readInt();
        for (var i = 0; i < map_values_size; i++) {
          var value = buffer.readInt();
          this.addMapping(key, value);
        }
      }
      return this;
    };
    TokenInfoDictionary.prototype.getFeatures = function(token_info_id_str) {
      var token_info_id = parseInt(token_info_id_str);
      if (isNaN(token_info_id)) {
        return "";
      }
      var pos_id = this.dictionary.getInt(token_info_id + 6);
      return this.pos_buffer.getString(pos_id);
    };
    TokenInfoDictionary_1 = TokenInfoDictionary;
    return TokenInfoDictionary_1;
  }
  var ConnectionCosts_1;
  var hasRequiredConnectionCosts;
  function requireConnectionCosts() {
    if (hasRequiredConnectionCosts) return ConnectionCosts_1;
    hasRequiredConnectionCosts = 1;
    function ConnectionCosts(forward_dimension, backward_dimension) {
      this.forward_dimension = forward_dimension;
      this.backward_dimension = backward_dimension;
      this.buffer = new Int16Array(forward_dimension * backward_dimension + 2);
      this.buffer[0] = forward_dimension;
      this.buffer[1] = backward_dimension;
    }
    ConnectionCosts.prototype.put = function(forward_id, backward_id, cost) {
      var index = forward_id * this.backward_dimension + backward_id + 2;
      if (this.buffer.length < index + 1) {
        throw "ConnectionCosts buffer overflow";
      }
      this.buffer[index] = cost;
    };
    ConnectionCosts.prototype.get = function(forward_id, backward_id) {
      var index = forward_id * this.backward_dimension + backward_id + 2;
      if (this.buffer.length < index + 1) {
        throw "ConnectionCosts buffer overflow";
      }
      return this.buffer[index];
    };
    ConnectionCosts.prototype.loadConnectionCosts = function(connection_costs_buffer) {
      this.forward_dimension = connection_costs_buffer[0];
      this.backward_dimension = connection_costs_buffer[1];
      this.buffer = connection_costs_buffer;
    };
    ConnectionCosts_1 = ConnectionCosts;
    return ConnectionCosts_1;
  }
  var CharacterClass_1;
  var hasRequiredCharacterClass;
  function requireCharacterClass() {
    if (hasRequiredCharacterClass) return CharacterClass_1;
    hasRequiredCharacterClass = 1;
    function CharacterClass(class_id, class_name, is_always_invoke, is_grouping, max_length) {
      this.class_id = class_id;
      this.class_name = class_name;
      this.is_always_invoke = is_always_invoke;
      this.is_grouping = is_grouping;
      this.max_length = max_length;
    }
    CharacterClass_1 = CharacterClass;
    return CharacterClass_1;
  }
  var InvokeDefinitionMap_1;
  var hasRequiredInvokeDefinitionMap;
  function requireInvokeDefinitionMap() {
    if (hasRequiredInvokeDefinitionMap) return InvokeDefinitionMap_1;
    hasRequiredInvokeDefinitionMap = 1;
    var ByteBuffer = requireByteBuffer();
    var CharacterClass = requireCharacterClass();
    function InvokeDefinitionMap() {
      this.map = [];
      this.lookup_table = {};
    }
    InvokeDefinitionMap.load = function(invoke_def_buffer) {
      var invoke_def = new InvokeDefinitionMap();
      var character_category_definition = [];
      var buffer = new ByteBuffer(invoke_def_buffer);
      while (buffer.position + 1 < buffer.size()) {
        var class_id = character_category_definition.length;
        var is_always_invoke = buffer.get();
        var is_grouping = buffer.get();
        var max_length = buffer.getInt();
        var class_name = buffer.getString();
        character_category_definition.push(new CharacterClass(class_id, class_name, is_always_invoke, is_grouping, max_length));
      }
      invoke_def.init(character_category_definition);
      return invoke_def;
    };
    InvokeDefinitionMap.prototype.init = function(character_category_definition) {
      if (character_category_definition == null) {
        return;
      }
      for (var i = 0; i < character_category_definition.length; i++) {
        var character_class = character_category_definition[i];
        this.map[i] = character_class;
        this.lookup_table[character_class.class_name] = i;
      }
    };
    InvokeDefinitionMap.prototype.getCharacterClass = function(class_id) {
      return this.map[class_id];
    };
    InvokeDefinitionMap.prototype.lookup = function(class_name) {
      var class_id = this.lookup_table[class_name];
      if (class_id == null) {
        return null;
      }
      return class_id;
    };
    InvokeDefinitionMap.prototype.toBuffer = function() {
      var buffer = new ByteBuffer();
      for (var i = 0; i < this.map.length; i++) {
        var char_class = this.map[i];
        buffer.put(char_class.is_always_invoke);
        buffer.put(char_class.is_grouping);
        buffer.putInt(char_class.max_length);
        buffer.putString(char_class.class_name);
      }
      buffer.shrink();
      return buffer.buffer;
    };
    InvokeDefinitionMap_1 = InvokeDefinitionMap;
    return InvokeDefinitionMap_1;
  }
  var CharacterDefinition_1;
  var hasRequiredCharacterDefinition;
  function requireCharacterDefinition() {
    if (hasRequiredCharacterDefinition) return CharacterDefinition_1;
    hasRequiredCharacterDefinition = 1;
    var InvokeDefinitionMap = requireInvokeDefinitionMap();
    var CharacterClass = requireCharacterClass();
    var SurrogateAwareString = requireSurrogateAwareString();
    var DEFAULT_CATEGORY = "DEFAULT";
    function CharacterDefinition() {
      this.character_category_map = new Uint8Array(65536);
      this.compatible_category_map = new Uint32Array(65536);
      this.invoke_definition_map = null;
    }
    CharacterDefinition.load = function(cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer) {
      var char_def = new CharacterDefinition();
      char_def.character_category_map = cat_map_buffer;
      char_def.compatible_category_map = compat_cat_map_buffer;
      char_def.invoke_definition_map = InvokeDefinitionMap.load(invoke_def_buffer);
      return char_def;
    };
    CharacterDefinition.parseCharCategory = function(class_id, parsed_category_def) {
      var category = parsed_category_def[1];
      var invoke = parseInt(parsed_category_def[2]);
      var grouping = parseInt(parsed_category_def[3]);
      var max_length = parseInt(parsed_category_def[4]);
      if (!isFinite(invoke) || invoke !== 0 && invoke !== 1) {
        console.log("char.def parse error. INVOKE is 0 or 1 in:" + invoke);
        return null;
      }
      if (!isFinite(grouping) || grouping !== 0 && grouping !== 1) {
        console.log("char.def parse error. GROUP is 0 or 1 in:" + grouping);
        return null;
      }
      if (!isFinite(max_length) || max_length < 0) {
        console.log("char.def parse error. LENGTH is 1 to n:" + max_length);
        return null;
      }
      var is_invoke = invoke === 1;
      var is_grouping = grouping === 1;
      return new CharacterClass(class_id, category, is_invoke, is_grouping, max_length);
    };
    CharacterDefinition.parseCategoryMapping = function(parsed_category_mapping) {
      var start = parseInt(parsed_category_mapping[1]);
      var default_category = parsed_category_mapping[2];
      var compatible_category = 3 < parsed_category_mapping.length ? parsed_category_mapping.slice(3) : [];
      if (!isFinite(start) || start < 0 || start > 65535) {
        console.log("char.def parse error. CODE is invalid:" + start);
      }
      return { start, default: default_category, compatible: compatible_category };
    };
    CharacterDefinition.parseRangeCategoryMapping = function(parsed_category_mapping) {
      var start = parseInt(parsed_category_mapping[1]);
      var end = parseInt(parsed_category_mapping[2]);
      var default_category = parsed_category_mapping[3];
      var compatible_category = 4 < parsed_category_mapping.length ? parsed_category_mapping.slice(4) : [];
      if (!isFinite(start) || start < 0 || start > 65535) {
        console.log("char.def parse error. CODE is invalid:" + start);
      }
      if (!isFinite(end) || end < 0 || end > 65535) {
        console.log("char.def parse error. CODE is invalid:" + end);
      }
      return { start, end, default: default_category, compatible: compatible_category };
    };
    CharacterDefinition.prototype.initCategoryMappings = function(category_mapping) {
      var code_point;
      if (category_mapping != null) {
        for (var i = 0; i < category_mapping.length; i++) {
          var mapping = category_mapping[i];
          var end = mapping.end || mapping.start;
          for (code_point = mapping.start; code_point <= end; code_point++) {
            this.character_category_map[code_point] = this.invoke_definition_map.lookup(mapping.default);
            for (var j = 0; j < mapping.compatible.length; j++) {
              var bitset = this.compatible_category_map[code_point];
              var compatible_category = mapping.compatible[j];
              if (compatible_category == null) {
                continue;
              }
              var class_id = this.invoke_definition_map.lookup(compatible_category);
              if (class_id == null) {
                continue;
              }
              var class_id_bit = 1 << class_id;
              bitset = bitset | class_id_bit;
              this.compatible_category_map[code_point] = bitset;
            }
          }
        }
      }
      var default_id = this.invoke_definition_map.lookup(DEFAULT_CATEGORY);
      if (default_id == null) {
        return;
      }
      for (code_point = 0; code_point < this.character_category_map.length; code_point++) {
        if (this.character_category_map[code_point] === 0) {
          this.character_category_map[code_point] = 1 << default_id;
        }
      }
    };
    CharacterDefinition.prototype.lookupCompatibleCategory = function(ch) {
      var classes = [];
      var code = ch.charCodeAt(0);
      var integer;
      if (code < this.compatible_category_map.length) {
        integer = this.compatible_category_map[code];
      }
      if (integer == null || integer === 0) {
        return classes;
      }
      for (var bit = 0; bit < 32; bit++) {
        if (integer << 31 - bit >>> 31 === 1) {
          var character_class = this.invoke_definition_map.getCharacterClass(bit);
          if (character_class == null) {
            continue;
          }
          classes.push(character_class);
        }
      }
      return classes;
    };
    CharacterDefinition.prototype.lookup = function(ch) {
      var class_id;
      var code = ch.charCodeAt(0);
      if (SurrogateAwareString.isSurrogatePair(ch)) {
        class_id = this.invoke_definition_map.lookup(DEFAULT_CATEGORY);
      } else if (code < this.character_category_map.length) {
        class_id = this.character_category_map[code];
      }
      if (class_id == null) {
        class_id = this.invoke_definition_map.lookup(DEFAULT_CATEGORY);
      }
      return this.invoke_definition_map.getCharacterClass(class_id);
    };
    CharacterDefinition_1 = CharacterDefinition;
    return CharacterDefinition_1;
  }
  var UnknownDictionary_1;
  var hasRequiredUnknownDictionary;
  function requireUnknownDictionary() {
    if (hasRequiredUnknownDictionary) return UnknownDictionary_1;
    hasRequiredUnknownDictionary = 1;
    var TokenInfoDictionary = requireTokenInfoDictionary();
    var CharacterDefinition = requireCharacterDefinition();
    var ByteBuffer = requireByteBuffer();
    function UnknownDictionary() {
      this.dictionary = new ByteBuffer(10 * 1024 * 1024);
      this.target_map = {};
      this.pos_buffer = new ByteBuffer(10 * 1024 * 1024);
      this.character_definition = null;
    }
    UnknownDictionary.prototype = Object.create(TokenInfoDictionary.prototype);
    UnknownDictionary.prototype.characterDefinition = function(character_definition) {
      this.character_definition = character_definition;
      return this;
    };
    UnknownDictionary.prototype.lookup = function(ch) {
      return this.character_definition.lookup(ch);
    };
    UnknownDictionary.prototype.lookupCompatibleCategory = function(ch) {
      return this.character_definition.lookupCompatibleCategory(ch);
    };
    UnknownDictionary.prototype.loadUnknownDictionaries = function(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer) {
      this.loadDictionary(unk_buffer);
      this.loadPosVector(unk_pos_buffer);
      this.loadTargetMap(unk_map_buffer);
      this.character_definition = CharacterDefinition.load(cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer);
    };
    UnknownDictionary_1 = UnknownDictionary;
    return UnknownDictionary_1;
  }
  var DynamicDictionaries_1;
  var hasRequiredDynamicDictionaries;
  function requireDynamicDictionaries() {
    if (hasRequiredDynamicDictionaries) return DynamicDictionaries_1;
    hasRequiredDynamicDictionaries = 1;
    var doublearray2 = requireDoublearray();
    var TokenInfoDictionary = requireTokenInfoDictionary();
    var ConnectionCosts = requireConnectionCosts();
    var UnknownDictionary = requireUnknownDictionary();
    function DynamicDictionaries(trie, token_info_dictionary, connection_costs, unknown_dictionary) {
      if (trie != null) {
        this.trie = trie;
      } else {
        this.trie = doublearray2.builder(0).build([
          { k: "", v: 1 }
        ]);
      }
      if (token_info_dictionary != null) {
        this.token_info_dictionary = token_info_dictionary;
      } else {
        this.token_info_dictionary = new TokenInfoDictionary();
      }
      if (connection_costs != null) {
        this.connection_costs = connection_costs;
      } else {
        this.connection_costs = new ConnectionCosts(0, 0);
      }
      if (unknown_dictionary != null) {
        this.unknown_dictionary = unknown_dictionary;
      } else {
        this.unknown_dictionary = new UnknownDictionary();
      }
    }
    DynamicDictionaries.prototype.loadTrie = function(base_buffer, check_buffer) {
      this.trie = doublearray2.load(base_buffer, check_buffer);
      return this;
    };
    DynamicDictionaries.prototype.loadTokenInfoDictionaries = function(token_info_buffer, pos_buffer, target_map_buffer) {
      this.token_info_dictionary.loadDictionary(token_info_buffer);
      this.token_info_dictionary.loadPosVector(pos_buffer);
      this.token_info_dictionary.loadTargetMap(target_map_buffer);
      return this;
    };
    DynamicDictionaries.prototype.loadConnectionCosts = function(cc_buffer) {
      this.connection_costs.loadConnectionCosts(cc_buffer);
      return this;
    };
    DynamicDictionaries.prototype.loadUnknownDictionaries = function(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer) {
      this.unknown_dictionary.loadUnknownDictionaries(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer);
      return this;
    };
    DynamicDictionaries_1 = DynamicDictionaries;
    return DynamicDictionaries_1;
  }
  var DictionaryLoader_1;
  var hasRequiredDictionaryLoader;
  function requireDictionaryLoader() {
    if (hasRequiredDictionaryLoader) return DictionaryLoader_1;
    hasRequiredDictionaryLoader = 1;
    var path = requirePathBrowserify();
    var async2 = requireAsync();
    var DynamicDictionaries = requireDynamicDictionaries();
    function DictionaryLoader(dic_path) {
      this.dic = new DynamicDictionaries();
      this.dic_path = dic_path;
    }
    DictionaryLoader.prototype.loadArrayBuffer = function(file, callback) {
      throw new Error("DictionaryLoader#loadArrayBuffer should be overwrite");
    };
    DictionaryLoader.prototype.load = function(load_callback) {
      var dic = this.dic;
      var dic_path = this.dic_path;
      var loadArrayBuffer = this.loadArrayBuffer;
      async2.parallel([
        // Trie
        function(callback) {
          async2.map(["base.dat.gz", "check.dat.gz"], function(filename, _callback) {
            loadArrayBuffer(path.join(dic_path, filename), function(err, buffer) {
              if (err) {
                return _callback(err);
              }
              _callback(null, buffer);
            });
          }, function(err, buffers) {
            if (err) {
              return callback(err);
            }
            var base_buffer = new Int32Array(buffers[0]);
            var check_buffer = new Int32Array(buffers[1]);
            dic.loadTrie(base_buffer, check_buffer);
            callback(null);
          });
        },
        // Token info dictionaries
        function(callback) {
          async2.map(["tid.dat.gz", "tid_pos.dat.gz", "tid_map.dat.gz"], function(filename, _callback) {
            loadArrayBuffer(path.join(dic_path, filename), function(err, buffer) {
              if (err) {
                return _callback(err);
              }
              _callback(null, buffer);
            });
          }, function(err, buffers) {
            if (err) {
              return callback(err);
            }
            var token_info_buffer = new Uint8Array(buffers[0]);
            var pos_buffer = new Uint8Array(buffers[1]);
            var target_map_buffer = new Uint8Array(buffers[2]);
            dic.loadTokenInfoDictionaries(token_info_buffer, pos_buffer, target_map_buffer);
            callback(null);
          });
        },
        // Connection cost matrix
        function(callback) {
          loadArrayBuffer(path.join(dic_path, "cc.dat.gz"), function(err, buffer) {
            if (err) {
              return callback(err);
            }
            var cc_buffer = new Int16Array(buffer);
            dic.loadConnectionCosts(cc_buffer);
            callback(null);
          });
        },
        // Unknown dictionaries
        function(callback) {
          async2.map(["unk.dat.gz", "unk_pos.dat.gz", "unk_map.dat.gz", "unk_char.dat.gz", "unk_compat.dat.gz", "unk_invoke.dat.gz"], function(filename, _callback) {
            loadArrayBuffer(path.join(dic_path, filename), function(err, buffer) {
              if (err) {
                return _callback(err);
              }
              _callback(null, buffer);
            });
          }, function(err, buffers) {
            if (err) {
              return callback(err);
            }
            var unk_buffer = new Uint8Array(buffers[0]);
            var unk_pos_buffer = new Uint8Array(buffers[1]);
            var unk_map_buffer = new Uint8Array(buffers[2]);
            var cat_map_buffer = new Uint8Array(buffers[3]);
            var compat_cat_map_buffer = new Uint32Array(buffers[4]);
            var invoke_def_buffer = new Uint8Array(buffers[5]);
            dic.loadUnknownDictionaries(unk_buffer, unk_pos_buffer, unk_map_buffer, cat_map_buffer, compat_cat_map_buffer, invoke_def_buffer);
            callback(null);
          });
        }
      ], function(err) {
        load_callback(err, dic);
      });
    };
    DictionaryLoader_1 = DictionaryLoader;
    return DictionaryLoader_1;
  }
  var BrowserDictionaryLoader_1;
  var hasRequiredBrowserDictionaryLoader;
  function requireBrowserDictionaryLoader() {
    if (hasRequiredBrowserDictionaryLoader) return BrowserDictionaryLoader_1;
    hasRequiredBrowserDictionaryLoader = 1;
    var zlib = requireGunzip_min();
    var DictionaryLoader = requireDictionaryLoader();
    function BrowserDictionaryLoader(dic_path) {
      DictionaryLoader.apply(this, [dic_path]);
    }
    BrowserDictionaryLoader.prototype = Object.create(DictionaryLoader.prototype);
    BrowserDictionaryLoader.prototype.loadArrayBuffer = function(url, callback) {
      var xhr = new XMLHttpRequest();
      xhr.open("GET", url, true);
      xhr.responseType = "arraybuffer";
      xhr.onload = function() {
        if (this.status > 0 && this.status !== 200) {
          callback(xhr.statusText, null);
          return;
        }
        var arraybuffer = this.response;
        var gz = new zlib.Zlib.Gunzip(new Uint8Array(arraybuffer));
        var typed_array = gz.decompress();
        callback(null, typed_array.buffer);
      };
      xhr.onerror = function(err) {
        callback(err, null);
      };
      xhr.send();
    };
    BrowserDictionaryLoader_1 = BrowserDictionaryLoader;
    return BrowserDictionaryLoader_1;
  }
  var TokenizerBuilder_1;
  var hasRequiredTokenizerBuilder;
  function requireTokenizerBuilder() {
    if (hasRequiredTokenizerBuilder) return TokenizerBuilder_1;
    hasRequiredTokenizerBuilder = 1;
    var Tokenizer = requireTokenizer();
    var DictionaryLoader = requireBrowserDictionaryLoader();
    function TokenizerBuilder(option) {
      if (option.dicPath == null) {
        this.dic_path = "dict/";
      } else {
        this.dic_path = option.dicPath;
      }
    }
    TokenizerBuilder.prototype.build = function(callback) {
      var loader = new DictionaryLoader(this.dic_path);
      loader.load(function(err, dic) {
        callback(err, new Tokenizer(dic));
      });
    };
    TokenizerBuilder_1 = TokenizerBuilder;
    return TokenizerBuilder_1;
  }
  var ConnectionCostsBuilder_1;
  var hasRequiredConnectionCostsBuilder;
  function requireConnectionCostsBuilder() {
    if (hasRequiredConnectionCostsBuilder) return ConnectionCostsBuilder_1;
    hasRequiredConnectionCostsBuilder = 1;
    var ConnectionCosts = requireConnectionCosts();
    function ConnectionCostsBuilder() {
      this.lines = 0;
      this.connection_cost = null;
    }
    ConnectionCostsBuilder.prototype.putLine = function(line) {
      if (this.lines === 0) {
        var dimensions = line.split(" ");
        var forward_dimension = dimensions[0];
        var backward_dimension = dimensions[1];
        if (forward_dimension < 0 || backward_dimension < 0) {
          throw "Parse error of matrix.def";
        }
        this.connection_cost = new ConnectionCosts(forward_dimension, backward_dimension);
        this.lines++;
        return this;
      }
      var costs = line.split(" ");
      if (costs.length !== 3) {
        return this;
      }
      var forward_id = parseInt(costs[0]);
      var backward_id = parseInt(costs[1]);
      var cost = parseInt(costs[2]);
      if (forward_id < 0 || backward_id < 0 || !isFinite(forward_id) || !isFinite(backward_id) || this.connection_cost.forward_dimension <= forward_id || this.connection_cost.backward_dimension <= backward_id) {
        throw "Parse error of matrix.def";
      }
      this.connection_cost.put(forward_id, backward_id, cost);
      this.lines++;
      return this;
    };
    ConnectionCostsBuilder.prototype.build = function() {
      return this.connection_cost;
    };
    ConnectionCostsBuilder_1 = ConnectionCostsBuilder;
    return ConnectionCostsBuilder_1;
  }
  var CharacterDefinitionBuilder_1;
  var hasRequiredCharacterDefinitionBuilder;
  function requireCharacterDefinitionBuilder() {
    if (hasRequiredCharacterDefinitionBuilder) return CharacterDefinitionBuilder_1;
    hasRequiredCharacterDefinitionBuilder = 1;
    var CharacterDefinition = requireCharacterDefinition();
    var InvokeDefinitionMap = requireInvokeDefinitionMap();
    var CATEGORY_DEF_PATTERN = /^(\w+)\s+(\d)\s+(\d)\s+(\d)/;
    var CATEGORY_MAPPING_PATTERN = /^(0x[0-9A-F]{4})(?:\s+([^#\s]+))(?:\s+([^#\s]+))*/;
    var RANGE_CATEGORY_MAPPING_PATTERN = /^(0x[0-9A-F]{4})\.\.(0x[0-9A-F]{4})(?:\s+([^#\s]+))(?:\s+([^#\s]+))*/;
    function CharacterDefinitionBuilder() {
      this.char_def = new CharacterDefinition();
      this.char_def.invoke_definition_map = new InvokeDefinitionMap();
      this.character_category_definition = [];
      this.category_mapping = [];
    }
    CharacterDefinitionBuilder.prototype.putLine = function(line) {
      var parsed_category_def = CATEGORY_DEF_PATTERN.exec(line);
      if (parsed_category_def != null) {
        var class_id = this.character_category_definition.length;
        var char_class = CharacterDefinition.parseCharCategory(class_id, parsed_category_def);
        if (char_class == null) {
          return;
        }
        this.character_category_definition.push(char_class);
        return;
      }
      var parsed_category_mapping = CATEGORY_MAPPING_PATTERN.exec(line);
      if (parsed_category_mapping != null) {
        var mapping = CharacterDefinition.parseCategoryMapping(parsed_category_mapping);
        this.category_mapping.push(mapping);
      }
      var parsed_range_category_mapping = RANGE_CATEGORY_MAPPING_PATTERN.exec(line);
      if (parsed_range_category_mapping != null) {
        var range_mapping = CharacterDefinition.parseRangeCategoryMapping(parsed_range_category_mapping);
        this.category_mapping.push(range_mapping);
      }
    };
    CharacterDefinitionBuilder.prototype.build = function() {
      this.char_def.invoke_definition_map.init(this.character_category_definition);
      this.char_def.initCategoryMappings(this.category_mapping);
      return this.char_def;
    };
    CharacterDefinitionBuilder_1 = CharacterDefinitionBuilder;
    return CharacterDefinitionBuilder_1;
  }
  var DictionaryBuilder_1;
  var hasRequiredDictionaryBuilder;
  function requireDictionaryBuilder() {
    if (hasRequiredDictionaryBuilder) return DictionaryBuilder_1;
    hasRequiredDictionaryBuilder = 1;
    var doublearray2 = requireDoublearray();
    var DynamicDictionaries = requireDynamicDictionaries();
    var TokenInfoDictionary = requireTokenInfoDictionary();
    var ConnectionCostsBuilder = requireConnectionCostsBuilder();
    var CharacterDefinitionBuilder = requireCharacterDefinitionBuilder();
    var UnknownDictionary = requireUnknownDictionary();
    function DictionaryBuilder() {
      this.tid_entries = [];
      this.unk_entries = [];
      this.cc_builder = new ConnectionCostsBuilder();
      this.cd_builder = new CharacterDefinitionBuilder();
    }
    DictionaryBuilder.prototype.addTokenInfoDictionary = function(line) {
      var new_entry = line.split(",");
      this.tid_entries.push(new_entry);
      return this;
    };
    DictionaryBuilder.prototype.putCostMatrixLine = function(line) {
      this.cc_builder.putLine(line);
      return this;
    };
    DictionaryBuilder.prototype.putCharDefLine = function(line) {
      this.cd_builder.putLine(line);
      return this;
    };
    DictionaryBuilder.prototype.putUnkDefLine = function(line) {
      this.unk_entries.push(line.split(","));
      return this;
    };
    DictionaryBuilder.prototype.build = function() {
      var dictionaries = this.buildTokenInfoDictionary();
      var unknown_dictionary = this.buildUnknownDictionary();
      return new DynamicDictionaries(dictionaries.trie, dictionaries.token_info_dictionary, this.cc_builder.build(), unknown_dictionary);
    };
    DictionaryBuilder.prototype.buildTokenInfoDictionary = function() {
      var token_info_dictionary = new TokenInfoDictionary();
      var dictionary_entries = token_info_dictionary.buildDictionary(this.tid_entries);
      var trie = this.buildDoubleArray();
      for (var token_info_id in dictionary_entries) {
        var surface_form = dictionary_entries[token_info_id];
        var trie_id = trie.lookup(surface_form);
        token_info_dictionary.addMapping(trie_id, token_info_id);
      }
      return {
        trie,
        token_info_dictionary
      };
    };
    DictionaryBuilder.prototype.buildUnknownDictionary = function() {
      var unk_dictionary = new UnknownDictionary();
      var dictionary_entries = unk_dictionary.buildDictionary(this.unk_entries);
      var char_def = this.cd_builder.build();
      unk_dictionary.characterDefinition(char_def);
      for (var token_info_id in dictionary_entries) {
        var class_name = dictionary_entries[token_info_id];
        var class_id = char_def.invoke_definition_map.lookup(class_name);
        unk_dictionary.addMapping(class_id, token_info_id);
      }
      return unk_dictionary;
    };
    DictionaryBuilder.prototype.buildDoubleArray = function() {
      var trie_id = 0;
      var words = this.tid_entries.map(function(entry) {
        var surface_form = entry[0];
        return { k: surface_form, v: trie_id++ };
      });
      var builder = doublearray2.builder(1024 * 1024);
      return builder.build(words);
    };
    DictionaryBuilder_1 = DictionaryBuilder;
    return DictionaryBuilder_1;
  }
  var kuromoji_1;
  var hasRequiredKuromoji;
  function requireKuromoji() {
    if (hasRequiredKuromoji) return kuromoji_1;
    hasRequiredKuromoji = 1;
    var TokenizerBuilder = requireTokenizerBuilder();
    var DictionaryBuilder = requireDictionaryBuilder();
    var kuromoji = {
      builder: function(option) {
        return new TokenizerBuilder(option);
      },
      dictionaryBuilder: function() {
        return new DictionaryBuilder();
      }
    };
    kuromoji_1 = kuromoji;
    return kuromoji_1;
  }
  requireKuromoji();
  const isBrowser = typeof window !== "undefined";
  if (!isBrowser && typeof module !== "undefined" && module.exports) ;
  function logMessage(message) {
    console.log(`[KameLoma] ${message}`);
  }
  const fontSizeInput = document.getElementById("fontSize");
  const fontSizeValue = document.getElementById("fontSizeValue");
  const fontColorInput = document.getElementById("fontColor");
  const fontColorValue = document.getElementById("fontColorValue");
  const annotateBtn = document.getElementById("annotateBtn");
  const clearBtn = document.getElementById("clearBtn");
  fontSizeInput.addEventListener("input", (e) => {
    fontSizeValue.textContent = `${e.target.value}px`;
  });
  fontColorInput.addEventListener("input", (e) => {
    fontColorValue.textContent = e.target.value;
  });
  annotateBtn.addEventListener("click", () => {
    const settings = {
      fontSize: fontSizeInput.value + "px",
      color: fontColorInput.value
    };
    logMessage("Annotate clicked with settings: " + JSON.stringify(settings));
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: "annotate",
          settings
        }, (response) => {
          if (chrome.runtime.lastError) {
            logMessage("Error: " + chrome.runtime.lastError.message);
          } else {
            logMessage("Message response: " + (response?.status || "no response"));
          }
        });
      }
    });
  });
  clearBtn.addEventListener("click", () => {
    logMessage("Clear clicked");
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "clear" }, (response) => {
          if (chrome.runtime.lastError) {
            logMessage("Error: " + chrome.runtime.lastError.message);
          } else {
            logMessage("Message response: " + (response?.status || "no response"));
          }
        });
      }
    });
  });
})();
